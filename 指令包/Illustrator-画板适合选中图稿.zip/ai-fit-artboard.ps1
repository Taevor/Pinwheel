﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$logFile = Join-Path $PSScriptRoot 'run.log'

function Write-Diag([string]$m) {
    try { Add-Content -LiteralPath $logFile -Value ((Get-Date -Format 'HH:mm:ss.fff') + ' ' + $m) -Encoding UTF8 } catch { }
}

$app = $null
try { $app = [System.Runtime.InteropServices.Marshal]::GetActiveObject('Illustrator.Application') } catch { }

if ($null -eq $app) {
    Write-Diag '未检测到正在运行的 Illustrator'
    Write-Error '未检测到运行中的 Illustrator，请先打开文档并选中图稿。'
    exit 1
}

try {
    $js = @'
var doc;
if (app.documents.length === 0) {
    throw new Error('当前没有打开的 Illustrator 文档');
}
doc = app.activeDocument;
var sel = doc.selection;
if (!sel || sel.length === 0) {
    throw new Error('请先选中要放进画板的图稿');
}

function boundsOfSelection(items) {
    var first = items[0].visibleBounds;
    var left = first[0];
    var top = first[1];
    var right = first[2];
    var bottom = first[3];
    for (var i = 1; i < items.length; i += 1) {
        var b = items[i].visibleBounds;
        if (b[0] < left) { left = b[0]; }
        if (b[1] > top) { top = b[1]; }
        if (b[2] > right) { right = b[2]; }
        if (b[3] < bottom) { bottom = b[3]; }
    }
    return [left, top, right, bottom];
}

var b = boundsOfSelection(sel);
var idx = doc.artboards.getActiveArtboardIndex();
var ab = doc.artboards[idx];
try {
    ab.artboardRect = b;
}
catch (e) {
    doc.fitArtboardToSelectedArt(idx);
}
app.redraw();
'OK:' + idx;
'@
    $result = $app.DoJavaScript($js)
    Write-Diag ('画板调整完成，返回：' + $result)
    Write-Output '已将当前画板调整至贴合选中图稿'
}
catch {
    Write-Diag ('画板调整失败: ' + $_.Exception.Message)
    Write-Error ('画板调整失败：' + $_.Exception.Message)
    exit 1
}
