﻿$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class WinApi {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
}
'@
$h = [WinApi]::GetForegroundWindow()
if ($h -eq [IntPtr]::Zero) { exit 1 }
[WinApi]::ShowWindow($h, 6) | Out-Null
