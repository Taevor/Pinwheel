﻿$ErrorActionPreference = 'Stop'
$log = Join-Path $PSScriptRoot 'run.log'

function Write-Log([string]$msg) {
    try {
        Add-Content -LiteralPath $log -Value ("{0:HH:mm:ss} {1}" -f (Get-Date), $msg) -Encoding UTF8
    } catch { }
}

try {
    Write-Log '开始执行'

    Add-Type -AssemblyName System.Windows.Forms

    [System.Windows.Forms.SendKeys]::SendWait('^c')
    Start-Sleep -Milliseconds 250

    $text = ''
    if ([System.Windows.Forms.Clipboard]::ContainsText()) {
        $text = [System.Windows.Forms.Clipboard]::GetText().Trim()
    }
    Write-Log "读取到文本长度: $($text.Length)"

    if ([string]::IsNullOrEmpty($text)) {
        Write-Error '未读取到选中的文字，请先选中要翻译的内容再触发指令。'
        exit 1
    }

    $maxChars = 900
    if ($text.Length -gt $maxChars) {
        $text = $text.Substring(0, $maxChars)
    }

    $bodyArray = @($text)
    $jsonBody = ConvertTo-Json -InputObject $bodyArray -Compress
    $url = 'https://edge.microsoft.com/translate/translatetext?from=&to=zh-Hans&isEnterpriseClient=false'

    $headers = @{ 'Content-Type' = 'application/json' }
    $response = Invoke-RestMethod -Uri $url -Method Post -Body $jsonBody -Headers $headers -TimeoutSec 15

    if ($null -eq $response -or $response.Count -eq 0) {
        throw '翻译接口返回空响应。'
    }

    $translated = $response[0].translations[0].text
    if ([string]::IsNullOrWhiteSpace($translated)) {
        throw '翻译结果为空，请稍后重试。'
    }

    [System.Windows.Forms.Clipboard]::SetText($translated)
    Write-Log "翻译成功，译文长度: $($translated.Length)"

    # ===== 结果窗口：单实例复用，追加历史 =====
    $windowScript = Join-Path $PSScriptRoot 'result_window.ps1'
    if (-not (Test-Path -LiteralPath $windowScript)) {
        throw "缺少结果窗口脚本：$windowScript"
    }

    # 用临时文件传递本次结果，避免命令行转义问题
    $payloadPath = Join-Path $PSScriptRoot 'last_result.json'
    $payload = @{
        source     = $text
        translated = $translated
        time       = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    } | ConvertTo-Json -Compress
    [System.IO.File]::WriteAllText($payloadPath, $payload, (New-Object System.Text.UTF8Encoding($false)))

    # 检查窗口进程是否已存在；存在则只通知它刷新，不存在则启动
    $mutexName = 'Global\PinwheelTranslateResultWindow'
    $exists = $false
    try {
        $m = [System.Threading.Mutex]::OpenExisting($mutexName)
        $exists = $true
        $m.Dispose()
    } catch { }

    if ($exists) {
        # 通过命名事件通知已有窗口刷新
        try {
            $ev = [System.Threading.EventWaitHandle]::OpenExisting('Global\PinwheelTranslateRefresh')
            $ev.Set() | Out-Null
            $ev.Dispose()
        } catch {
            Write-Log '通知已有窗口刷新失败，将启动新窗口'
            $exists = $false
        }
    }

    if (-not $exists) {
        Start-Process -FilePath 'powershell.exe' -ArgumentList @(
            '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden',
            '-File', "`"$windowScript`""
        ) -WindowStyle Hidden
    }

    Write-Output "已翻译并复制到剪贴板：$translated"
    exit 0
}
catch {
    Write-Log "发生异常: $($_.Exception.Message)"
    Write-Error "翻译失败：$($_.Exception.Message)"
    exit 1
}