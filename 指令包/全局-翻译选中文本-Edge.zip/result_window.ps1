﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$scriptDir = $PSScriptRoot
$payloadPath = Join-Path $scriptDir 'last_result.json'
$mutexName = 'Global\PinwheelTranslateResultWindow'
$eventName = 'Global\PinwheelTranslateRefresh'

$createdNew = $false
$mutex = New-Object System.Threading.Mutex($true, $mutexName, [ref]$createdNew)
if (-not $createdNew) { exit 0 }

$refreshEvent = New-Object System.Threading.EventWaitHandle($false, [System.Threading.EventResetMode]::AutoReset, $eventName)

# ---- 颜色与字体 ----
$clrBg        = [System.Drawing.ColorTranslator]::FromHtml('#F3F3F3')
$clrCard      = [System.Drawing.ColorTranslator]::FromHtml('#FFFFFF')
$clrBorder    = [System.Drawing.ColorTranslator]::FromHtml('#E5E5E5')
$clrText      = [System.Drawing.ColorTranslator]::FromHtml('#1A1A1A')
$clrSubText   = [System.Drawing.ColorTranslator]::FromHtml('#6B6B6B')
$clrAccent    = [System.Drawing.ColorTranslator]::FromHtml('#0067C0')
$clrAccentHover = [System.Drawing.ColorTranslator]::FromHtml('#005A9E')

$fontFamily = 'Segoe UI Variable'
try { $testFont = New-Object System.Drawing.Font($fontFamily, 10) ; $testFont.Dispose() }
catch { $fontFamily = 'Segoe UI' }

$fontTitle  = New-Object System.Drawing.Font($fontFamily, 14, [System.Drawing.FontStyle]::Bold)
$fontBody   = New-Object System.Drawing.Font($fontFamily, 10)
$fontSmall  = New-Object System.Drawing.Font($fontFamily, 9)
$fontButton = New-Object System.Drawing.Font($fontFamily, 10)

# ---- 圆角工具 ----
function Set-RoundedRegion($ctrl, [int]$radius) {
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $r = $radius
    $w = $ctrl.Width; $h = $ctrl.Height
    $path.AddArc(0, 0, $r, $r, 180, 90)
    $path.AddArc($w - $r, 0, $r, $r, 270, 90)
    $path.AddArc($w - $r, $h - $r, $r, $r, 0, 90)
    $path.AddArc(0, $h - $r, $r, $r, 90, 90)
    $path.CloseFigure()
    $ctrl.Region = New-Object System.Drawing.Region($path)
    $path.Dispose()
}

# ---- 窗体 ----
$form = New-Object System.Windows.Forms.Form
$form.Text = '翻译结果'
$form.Size = New-Object System.Drawing.Size(760, 560)
$form.StartPosition = 'CenterScreen'
$form.BackColor = $clrBg
$form.Font = $fontBody
$form.MinimumSize = New-Object System.Drawing.Size(520, 360)
$form.FormBorderStyle = 'Sizable'
$form.Padding = New-Object System.Windows.Forms.Padding(16)

# ---- 顶部标题 ----
$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = '翻译结果'
$lblTitle.Font = $fontTitle
$lblTitle.ForeColor = $clrText
$lblTitle.AutoSize = $true
$lblTitle.Location = New-Object System.Drawing.Point(20, 16)
$form.Controls.Add($lblTitle)

$lblHint = New-Object System.Windows.Forms.Label
$lblHint.Text = '下方历史可手动编辑或删除'
$lblHint.Font = $fontSmall
$lblHint.ForeColor = $clrSubText
$lblHint.AutoSize = $true
$lblHint.Location = New-Object System.Drawing.Point(22, 46)
$form.Controls.Add($lblHint)

# ---- 底部操作栏（先加，Dock Bottom 优先）----
$panelBottom = New-Object System.Windows.Forms.Panel
$panelBottom.Dock = 'Bottom'
$panelBottom.Height = 52
$panelBottom.BackColor = $clrBg
$form.Controls.Add($panelBottom)

function New-FluentButton($text, $x) {
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = $text
    $btn.Font = $fontButton
    $btn.Size = New-Object System.Drawing.Size(110, 34)
    $btn.Location = New-Object System.Drawing.Point($x, 9)
    $btn.FlatStyle = 'Flat'
    $btn.FlatAppearance.BorderSize = 0
    $btn.BackColor = $clrCard
    $btn.ForeColor = $clrText
    $btn.Cursor = [System.Windows.Forms.Cursors]::Hand
    $btn.Add_MouseEnter({ $this.BackColor = [System.Drawing.ColorTranslator]::FromHtml('#EBEBEB') })
    $btn.Add_MouseLeave({ $this.BackColor = $clrCard })
    # 延迟到有尺寸后圆角
    $btn.Add_HandleCreated({ Set-RoundedRegion $this 6 })
    return $btn
}

$btnCopy = New-FluentButton '复制选中' 0
$panelBottom.Controls.Add($btnCopy)

$btnClear = New-FluentButton '清空历史' 120
$panelBottom.Controls.Add($btnClear)

$btnClose = New-FluentButton '关闭' 240
$btnClose.BackColor = $clrAccent
$btnClose.ForeColor = [System.Drawing.Color]::White
$btnClose.Add_MouseEnter({ $this.BackColor = $clrAccentHover })
$btnClose.Add_MouseLeave({ $this.BackColor = $clrAccent })
$panelBottom.Controls.Add($btnClose)

# ---- 主体区域 ----
$panelMain = New-Object System.Windows.Forms.Panel
$panelMain.Dock = 'Fill'
$panelMain.BackColor = $clrBg
$panelMain.Padding = New-Object System.Windows.Forms.Padding(0, 70, 0, 0)
$form.Controls.Add($panelMain)

# 原文卡片
$cardSource = New-Object System.Windows.Forms.Panel
$cardSource.Dock = 'Top'
$cardSource.Height = 120
$cardSource.BackColor = $clrCard
$cardSource.Padding = New-Object System.Windows.Forms.Padding(12)
$cardSource.Add_HandleCreated({ Set-RoundedRegion $this 10 })
$panelMain.Controls.Add($cardSource)

$lblSourceTitle = New-Object System.Windows.Forms.Label
$lblSourceTitle.Text = '原文'
$lblSourceTitle.Font = $fontSmall
$lblSourceTitle.ForeColor = $clrSubText
$lblSourceTitle.Dock = 'Top'
$lblSourceTitle.Height = 20
$cardSource.Controls.Add($lblSourceTitle)

$txtSource = New-Object System.Windows.Forms.TextBox
$txtSource.Multiline = $true
$txtSource.ScrollBars = 'Vertical'
$txtSource.ReadOnly = $true
$txtSource.Dock = 'Fill'
$txtSource.BorderStyle = 'None'
$txtSource.BackColor = $clrCard
$txtSource.ForeColor = $clrText
$txtSource.Font = $fontBody
$cardSource.Controls.Add($txtSource)
$txtSource.BringToFront()

# 历史卡片
$cardHistory = New-Object System.Windows.Forms.Panel
$cardHistory.Dock = 'Fill'
$cardHistory.BackColor = $clrCard
$cardHistory.Padding = New-Object System.Windows.Forms.Padding(12)
$cardHistory.Margin = New-Object System.Windows.Forms.Padding(0, 12, 0, 0)
$cardHistory.Add_HandleCreated({ Set-RoundedRegion $this 10 })
$panelMain.Controls.Add($cardHistory)

$lblHistoryTitle = New-Object System.Windows.Forms.Label
$lblHistoryTitle.Text = '翻译历史'
$lblHistoryTitle.Font = $fontSmall
$lblHistoryTitle.ForeColor = $clrSubText
$lblHistoryTitle.Dock = 'Top'
$lblHistoryTitle.Height = 20
$cardHistory.Controls.Add($lblHistoryTitle)

$txtHistory = New-Object System.Windows.Forms.RichTextBox
$txtHistory.Dock = 'Fill'
$txtHistory.ReadOnly = $false
$txtHistory.BorderStyle = 'None'
$txtHistory.BackColor = $clrCard
$txtHistory.ForeColor = $clrText
$txtHistory.Font = $fontBody
$txtHistory.DetectUrls = $false
$cardHistory.Controls.Add($txtHistory)
$txtHistory.BringToFront()

# 让历史卡片和原文卡片之间留出间距
$spacer = New-Object System.Windows.Forms.Panel
$spacer.Dock = 'Top'
$spacer.Height = 12
$spacer.BackColor = $clrBg
$panelMain.Controls.Add($spacer)
$spacer.BringToFront()
$cardHistory.BringToFront()

# ---- 数据加载 ----
function Load-Payload {
    if (-not (Test-Path -LiteralPath $payloadPath)) { return }
    try {
        $json = Get-Content -LiteralPath $payloadPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $script:txtSource.Text = $json.source
        $entry = "[$($json.time)]`r`n$($json.translated)`r`n`r`n"
        $txtHistory.AppendText($entry)
        $txtHistory.SelectionStart = $txtHistory.TextLength
        $txtHistory.ScrollToCaret()
    } catch { }
}
Load-Payload

# ---- 事件 ----
$btnClear.Add_Click({ $txtHistory.Clear() })
$btnCopy.Add_Click({
    if ($txtHistory.SelectedText) {
        [System.Windows.Forms.Clipboard]::SetText($txtHistory.SelectedText)
    }
})
$btnClose.Add_Click({ $form.Close() })

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 300
$timer.Add_Tick({ if ($refreshEvent.WaitOne(0)) { Load-Payload } })
$timer.Start()

$form.Add_FormClosed({
    $timer.Stop()
    $refreshEvent.Dispose()
    $mutex.ReleaseMutex()
    $mutex.Dispose()
})

[System.Windows.Forms.Application]::Run($form)