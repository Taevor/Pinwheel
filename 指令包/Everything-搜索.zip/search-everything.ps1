﻿$ErrorActionPreference = 'Stop'
$log = Join-Path $PSScriptRoot 'run.log'

function Write-Log([string]$msg) {
    try {
        Add-Content -LiteralPath $log -Value ("{0:HH:mm:ss} {1}" -f (Get-Date), $msg) -Encoding UTF8
    } catch { }
}

try {
    Write-Log '开始执行'
    Add-Type -AssemblyName System.Windows.Forms

    [System.Windows.Forms.SendKeys]::SendWait('^c')
    Start-Sleep -Milliseconds 150

    $text = [System.Windows.Forms.Clipboard]::GetText().Trim()
    Write-Log "剪贴板内容长度: $($text.Length)"

    if ([string]::IsNullOrEmpty($text)) {
        Write-Log '剪贴板为空，退出'
        Write-Error '未读取到选中的文字，请先选中要搜索的内容。'
        exit 1
    }

    $candidates = @(
        "$env:ProgramFiles\Everything\Everything.exe",
        "${env:ProgramFiles(x86)}\Everything\Everything.exe",
        "$env:LOCALAPPDATA\Programs\Everything\Everything.exe",
        "$env:ProgramData\Everything\Everything.exe"
    )

    $exe = $null
    foreach ($path in $candidates) {
        if (Test-Path -LiteralPath $path) {
            $exe = $path
            break
        }
    }

    if (-not $exe) {
        try {
            $dir = (Get-ItemProperty -LiteralPath 'HKCU:\Software\voidtools\Everything' -Name 'InstallLocation' -ErrorAction Stop).InstallLocation
            if ($dir) {
                $candidate = Join-Path $dir 'Everything.exe'
                if (Test-Path -LiteralPath $candidate) { $exe = $candidate }
            }
        } catch { }
    }

    Write-Log "找到的 Everything: $exe"
    if (-not $exe) {
        Write-Error '未检测到 Everything，请先安装 voidtools Everything。'
        exit 1
    }

    & $exe -search $text
    Write-Log '已发送搜索命令'
    Write-Output "已在 Everything 中搜索：$text"
}
catch {
    Write-Log "发生异常: $($_.Exception.Message)"
    Write-Error "搜索失败：$($_.Exception.Message)"
    exit 1
}
