﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$logFile = Join-Path $PSScriptRoot 'run.log'

function Write-Diag([string]$m) {
    try { Add-Content -LiteralPath $logFile -Value ((Get-Date -Format 'HH:mm:ss.fff') + ' ' + $m) -Encoding UTF8 } catch { }
}

$app = $null
try { $app = [System.Runtime.InteropServices.Marshal]::GetActiveObject('Illustrator.Application') } catch { }

if ($null -eq $app) {
    Write-Diag '未检测到正在运行的 Illustrator'
    Write-Error '未检测到运行中的 Illustrator，请先打开文档并选中对象。'
    exit 1
}

try {
    $js = @'
var doc;
if (app.documents.length === 0) {
    throw new Error('当前没有打开的 Illustrator 文档');
}
doc = app.activeDocument;
var sel = doc.selection;
if (!sel || sel.length === 0) {
    throw new Error('请先选中要缩放的对象');
}

function boundsOfSelection(items) {
    var first = items[0].visibleBounds;
    var left = first[0];
    var top = first[1];
    var right = first[2];
    var bottom = first[3];
    for (var i = 1; i < items.length; i += 1) {
        var b = items[i].visibleBounds;
        if (b[0] < left) { left = b[0]; }
        if (b[1] > top) { top = b[1]; }
        if (b[2] > right) { right = b[2]; }
        if (b[3] < bottom) { bottom = b[3]; }
    }
    return [left, top, right, bottom];
}

var b = boundsOfSelection(sel);
var selWidth = b[2] - b[0];
var selHeight = b[1] - b[3];
if (selWidth <= 0 || selHeight <= 0) {
    throw new Error('选中对象无法计算范围');
}

var view = doc.views[0];
var vb = view.bounds;
var viewWidth = vb[2] - vb[0];
var viewHeight = vb[1] - vb[3];
if (viewWidth <= 0 || viewHeight <= 0) {
    throw new Error('无法读取当前窗口范围');
}

// view.zoom 用倍率表示（1 表示 100%）。
// 先把当前视口换算成 100% 时的尺寸，再计算目标倍率，避免当前缩放影响结果。
var currentZoom = view.zoom;
var viewWidth100 = viewWidth * currentZoom;
var viewHeight100 = viewHeight * currentZoom;

// 留 8% 边距，让选中对象完整落在屏幕中间，类似 CorelDRAW 的 F4。
var zoom = Math.min(viewWidth100 / selWidth, viewHeight100 / selHeight) * 0.92;
if (zoom > 64) { zoom = 64; }
if (zoom < 0.01) { zoom = 0.01; }

view.zoom = zoom;
view.centerPoint = [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2];
app.redraw();
'OK:' + (zoom * 100).toFixed(2) + '%';
'@
    $result = $app.DoJavaScript($js)
    Write-Diag ('缩放完成，返回：' + $result)
    Write-Output '已将选中的对象缩放并居中到当前窗口'
}
catch {
    Write-Diag ('缩放失败: ' + $_.Exception.Message)
    Write-Error ('缩放失败：' + $_.Exception.Message)
    exit 1
}
