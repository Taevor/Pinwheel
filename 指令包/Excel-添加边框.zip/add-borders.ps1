﻿$ErrorActionPreference = 'Stop'

$logFile = Join-Path $PSScriptRoot 'run.log'

function Write-Diag([string]$m) {
    try { Add-Content -LiteralPath $logFile -Value ((Get-Date -Format 'HH:mm:ss.fff') + ' ' + $m) -Encoding UTF8 } catch { }
}

function Get-ExcelApp {
    # Excel 专用；重试 3 次，每次间隔 300ms 应对 ROT 短暂空窗
    for ($attempt = 0; $attempt -lt 3; $attempt++) {
        try {
            $obj = [System.Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application')
            if ($obj) {
                Write-Diag '已连接 COM: Excel.Application'
                return $obj
            }
        } catch { }
        Start-Sleep -Milliseconds 300
    }
    return $null
}

$app = Get-ExcelApp

if ($null -eq $app) {
    Write-Diag '未检测到正在运行的 Excel'
    Write-Error '未检测到正在运行的 Excel，请先打开表格并选中单元格。'
    exit 1
}

try {
    $selection = $app.Selection
    $borders = $selection.Borders

    # xlContinuous = 1，先让所有边都有线
    $borders.LineStyle = 1
    # xlThin = 2，内部和外侧先都用细线
    $borders.Weight = 2
    # xlAutomatic = -4105，用默认颜色
    $borders.ColorIndex = -4105

    # xlEdgeLeft=7, xlEdgeTop=8, xlEdgeBottom=9, xlEdgeRight=10
    # xlThick = 4，外侧四条边改成粗线
    foreach ($edge in @(7, 8, 9, 10)) {
        $selection.Borders.Item($edge).Weight = 4
    }

    Write-Diag '添加边框完成'
    Write-Output '已为选中区域添加边框（内细外粗）'
}
catch {
    Write-Diag ('添加边框失败: ' + $_.Exception.Message)
    Write-Error ('添加边框失败：' + $_.Exception.Message)
    exit 1
}