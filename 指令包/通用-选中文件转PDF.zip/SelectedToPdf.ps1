﻿param(
    [string[]]$Files
)

$ErrorActionPreference = 'Stop'

# Keep toast text readable when Pinwheel captures standard output/error.
try {
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [Console]::OutputEncoding = $utf8NoBom
    $OutputEncoding = $utf8NoBom
} catch { }

$script:Invariant = [System.Globalization.CultureInfo]::InvariantCulture
$script:ImageExt = @('.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tif', '.tiff')
$script:WordExt = @('.doc', '.docx', '.docm', '.dot', '.dotx', '.dotm', '.rtf', '.wps', '.wpt', '.odt')
$script:ExcelExt = @('.xls', '.xlsx', '.xlsm', '.xlsb', '.xlt', '.xltx', '.xltm', '.et', '.ett', '.ods', '.csv')
$script:PptExt = @('.ppt', '.pptx', '.pptm', '.pps', '.ppsx', '.ppsm', '.pot', '.potx', '.potm', '.dps', '.dpt', '.odp')

$script:AppCache = @{}
$script:AppOrder = New-Object System.Collections.ArrayList
$script:TempFiles = New-Object System.Collections.ArrayList

if (-not ('Pinwheel.NativeMethods' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace Pinwheel {
    public static class NativeMethods {
        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct LVITEM {
            public uint mask;
            public int iItem;
            public int iSubItem;
            public uint state;
            public uint stateMask;
            public IntPtr pszText;
            public int cchTextMax;
            public int iImage;
            public IntPtr lParam;
            public int iIndent;
            public int iGroupId;
            public uint cColumns;
            public IntPtr puColumns;
            public IntPtr piColFmt;
            public int iGroup;
        }

        private const uint LVM_FIRST = 0x1000;
        private const uint LVM_GETITEMCOUNT = LVM_FIRST + 4;
        private const uint LVM_GETNEXTITEM = LVM_FIRST + 12;
        private const uint LVM_GETITEMTEXTW = LVM_FIRST + 115;
        private const uint LVNI_SELECTED = 0x0002;
        private const uint LVIF_TEXT = 0x0001;

        private const uint PROCESS_VM_OPERATION = 0x0008;
        private const uint PROCESS_VM_READ = 0x0010;
        private const uint PROCESS_VM_WRITE = 0x0020;
        private const uint MEM_COMMIT = 0x1000;
        private const uint MEM_RESERVE = 0x2000;
        private const uint MEM_RELEASE = 0x8000;
        private const uint PAGE_READWRITE = 0x04;

        [DllImport("user32.dll")]
        public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll")]
        public static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr FindWindowEx(IntPtr hWndParent, IntPtr hWndChildAfter, string lpszClass, string lpszWindow);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, uint dwProcessId);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, UIntPtr dwSize, uint flAllocationType, uint flProtect);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool VirtualFreeEx(IntPtr hProcess, IntPtr lpAddress, UIntPtr dwSize, uint dwFreeType);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, IntPtr lpBuffer, uint nSize, out IntPtr lpNumberOfBytesWritten);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool ReadProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out IntPtr lpNumberOfBytesRead);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CloseHandle(IntPtr hObject);

        public static IntPtr[] GetVisibleTopLevelWindows() {
            List<IntPtr> list = new List<IntPtr>();
            EnumWindows(delegate(IntPtr hWnd, IntPtr lParam) {
                if (IsWindowVisible(hWnd)) {
                    list.Add(hWnd);
                }
                return true;
            }, IntPtr.Zero);
            return list.ToArray();
        }

        public static string GetWindowClassName(IntPtr hWnd) {
            StringBuilder builder = new StringBuilder(256);
            GetClassName(hWnd, builder, builder.Capacity);
            return builder.ToString();
        }

        public static uint GetWindowProcessId(IntPtr hWnd) {
            uint processId;
            GetWindowThreadProcessId(hWnd, out processId);
            return processId;
        }

        public static IntPtr FindDesktopListView() {
            IntPtr progman = FindWindow("Progman", null);
            IntPtr defView = IntPtr.Zero;

            if (progman != IntPtr.Zero) {
                defView = FindWindowEx(progman, IntPtr.Zero, "SHELLDLL_DefView", null);
            }

            if (defView == IntPtr.Zero) {
                EnumWindows(delegate(IntPtr hWnd, IntPtr lParam) {
                    IntPtr candidate = FindWindowEx(hWnd, IntPtr.Zero, "SHELLDLL_DefView", null);
                    if (candidate != IntPtr.Zero) {
                        defView = candidate;
                        return false;
                    }
                    return true;
                }, IntPtr.Zero);
            }

            if (defView == IntPtr.Zero) { return IntPtr.Zero; }
            IntPtr listView = FindWindowEx(defView, IntPtr.Zero, "SysListView32", "FolderView");
            if (listView == IntPtr.Zero) {
                listView = FindWindowEx(defView, IntPtr.Zero, "SysListView32", null);
            }
            return listView;
        }

        public static string[] GetSelectedListViewTexts(IntPtr listView) {
            List<string> texts = new List<string>();
            if (listView == IntPtr.Zero) { return texts.ToArray(); }

            int index = -1;
            while (true) {
                index = (int)SendMessage(listView, LVM_GETNEXTITEM, (IntPtr)index, (IntPtr)LVNI_SELECTED);
                if (index < 0) { break; }

                string text = GetListViewItemText(listView, index);
                if (!String.IsNullOrEmpty(text)) { texts.Add(text); }
                if (texts.Count >= 512) { break; }
            }
            return texts.ToArray();
        }

        private static string GetListViewItemText(IntPtr listView, int index) {
            uint processId;
            GetWindowThreadProcessId(listView, out processId);
            if (processId == 0) { return null; }

            IntPtr process = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, false, processId);
            if (process == IntPtr.Zero) { return null; }

            int itemSize = Marshal.SizeOf(typeof(LVITEM));
            int textBytes = 520;
            IntPtr remote = IntPtr.Zero;
            IntPtr local = IntPtr.Zero;

            try {
                remote = VirtualAllocEx(process, IntPtr.Zero, (UIntPtr)(uint)(itemSize + textBytes), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
                if (remote == IntPtr.Zero) { return null; }

                local = Marshal.AllocHGlobal(itemSize);
                LVITEM item = new LVITEM();
                item.mask = LVIF_TEXT;
                item.iItem = index;
                item.iSubItem = 0;
                item.pszText = new IntPtr(remote.ToInt64() + itemSize);
                item.cchTextMax = 260;
                Marshal.StructureToPtr(item, local, false);

                IntPtr written;
                if (!WriteProcessMemory(process, remote, local, (uint)itemSize, out written)) { return null; }

                SendMessage(listView, LVM_GETITEMTEXTW, (IntPtr)index, remote);

                byte[] buffer = new byte[textBytes];
                IntPtr read;
                if (!ReadProcessMemory(process, item.pszText, buffer, (uint)textBytes, out read)) { return null; }

                int length = 0;
                while (length + 1 < buffer.Length && !(buffer[length] == 0 && buffer[length + 1] == 0)) {
                    length += 2;
                }
                return Encoding.Unicode.GetString(buffer, 0, length);
            }
            finally {
                if (local != IntPtr.Zero) { Marshal.FreeHGlobal(local); }
                if (remote != IntPtr.Zero) { VirtualFreeEx(process, remote, UIntPtr.Zero, MEM_RELEASE); }
                CloseHandle(process);
            }
        }
    }
}
'@
}

function Write-StreamAscii {
    param(
        [System.IO.Stream]$Stream,
        [string]$Text
    )
    $bytes = [System.Text.Encoding]::ASCII.GetBytes($Text)
    $Stream.Write($bytes, 0, $bytes.Length)
}

function Format-PdfNumber {
    param([double]$Value)
    return $Value.ToString('0.###', $script:Invariant)
}

function Get-SelectedFilesFromExplorer {
    $result = New-Object System.Collections.Generic.List[string]
    $shell = $null

    try {
        $shell = New-Object -ComObject Shell.Application
        $windows = @($shell.Windows())
        if ($windows.Count -eq 0) { return @() }

        $zOrder = @([Pinwheel.NativeMethods]::GetVisibleTopLevelWindows())
        $zIndex = @{}
        for ($i = 0; $i -lt $zOrder.Count; $i++) {
            $zIndex[[int64]$zOrder[$i]] = $i
        }
        $foreground = [int64][Pinwheel.NativeMethods]::GetForegroundWindow()

        $foregroundWindow = $null
        foreach ($window in $windows) {
            try {
                if ([int64]$window.HWND -eq $foreground) {
                    $foregroundWindow = $window
                    break
                }
            } catch { }
        }

        if ($foregroundWindow) {
            try {
                $document = $foregroundWindow.Document
                if ($document) {
                    foreach ($item in @($document.SelectedItems())) {
                        try {
                            $path = [string]$item.Path
                            if ($path -and (Test-Path -LiteralPath $path -PathType Leaf)) {
                                [void]$result.Add($path)
                            }
                        } catch { }
                    }
                }
            } catch { }
            return @($result | Select-Object -Unique)
        }

        $candidates = New-Object System.Collections.ArrayList
        foreach ($window in $windows) {
            try {
                $handle = [int64]$window.HWND
                $z = 99999
                if ($zIndex.ContainsKey($handle)) { $z = [int]$zIndex[$handle] }
                [void]$candidates.Add([pscustomobject]@{ Window = $window; Z = $z })
            } catch { }
        }

        foreach ($candidate in @($candidates | Sort-Object Z)) {
            try {
                $document = $candidate.Window.Document
                if ($null -eq $document) { continue }

                $items = @($document.SelectedItems())
                if ($items.Count -eq 0) { continue }

                foreach ($item in $items) {
                    try {
                        $path = [string]$item.Path
                        if ($path -and (Test-Path -LiteralPath $path -PathType Leaf)) {
                            [void]$result.Add($path)
                        }
                    } catch { }
                }

                if ($result.Count -gt 0) { break }
            } catch { }
        }
    } catch { }
    finally {
        if ($shell) {
            try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($shell) } catch { }
        }
    }

    return @($result | Select-Object -Unique)
}

function Get-DesktopSelectedFiles {
    $listHandle = [Pinwheel.NativeMethods]::FindDesktopListView()
    if ($listHandle -eq [IntPtr]::Zero) { return @() }

    $texts = @([Pinwheel.NativeMethods]::GetSelectedListViewTexts($listHandle))
    if ($texts.Count -eq 0) { return @() }

    $desktopDirectories = New-Object System.Collections.ArrayList
    foreach ($folderName in @('Desktop', 'CommonDesktopDirectory')) {
        try {
            $folder = [Environment]::GetFolderPath($folderName)
            if ($folder -and (Test-Path -LiteralPath $folder) -and ($desktopDirectories -notcontains $folder)) {
                [void]$desktopDirectories.Add($folder)
            }
        } catch { }
    }

    $candidates = New-Object System.Collections.ArrayList
    foreach ($directory in $desktopDirectories) {
        try {
            foreach ($file in @(Get-ChildItem -LiteralPath $directory -Force -File -ErrorAction SilentlyContinue)) {
                [void]$candidates.Add($file)
            }
        } catch { }
    }

    $result = New-Object System.Collections.Generic.List[string]
    $seen = @{}
    foreach ($text in $texts) {
        $hits = @($candidates | Where-Object { $_.Name -eq $text -or $_.BaseName -eq $text })
        if ($hits.Count -eq 0) { continue }

        $choice = @($hits | Where-Object { $_.Name -eq $text }) | Select-Object -First 1
        if (-not $choice) {
            $preferred = @($hits | Where-Object { $_.Extension -ne '.lnk' -and $_.Extension -ne '.pdf' })
            if ($preferred.Count -gt 0) {
                $choice = $preferred[0]
            } else {
                $choice = $hits[0]
            }
        }

        if ($choice) {
            $key = $choice.FullName.ToLowerInvariant()
            if (-not $seen.ContainsKey($key)) {
                $seen[$key] = $true
                [void]$result.Add($choice.FullName)
            }
        }
    }

    return @($result)
}

function Test-DesktopForeground {
    $foreground = [Pinwheel.NativeMethods]::GetForegroundWindow()
    if ($foreground -eq [IntPtr]::Zero) { return $false }
    $className = [Pinwheel.NativeMethods]::GetWindowClassName($foreground)
    return @('Progman', 'WorkerW', 'SysListView32') -contains $className
}

function Get-CurrentSelection {
    $foreground = [Pinwheel.NativeMethods]::GetForegroundWindow()
    $className = [Pinwheel.NativeMethods]::GetWindowClassName($foreground)

    if (@('Progman', 'WorkerW', 'SysListView32') -contains $className) {
        return @(Get-DesktopSelectedFiles)
    }

    $explorerFiles = @(Get-SelectedFilesFromExplorer)
    if ($explorerFiles.Count -gt 0) { return $explorerFiles }

    if (@('CabinetWClass', 'ExploreWClass') -contains $className) {
        return @()
    }

    return @(Get-DesktopSelectedFiles)
}

function Resolve-InputFiles {
    param([string[]]$Items)

    $result = New-Object System.Collections.Generic.List[string]
    $seen = @{}

    foreach ($item in $Items) {
        if ([string]::IsNullOrWhiteSpace($item)) { continue }
        try {
            $full = [System.IO.Path]::GetFullPath($item)
            if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { continue }
            $key = $full.ToLowerInvariant()
            if (-not $seen.ContainsKey($key)) {
                $seen[$key] = $true
                [void]$result.Add($full)
            }
        } catch { }
    }

    return @($result)
}

function Get-ProcessIds {
    param([string[]]$Names)

    $ids = New-Object System.Collections.Generic.List[int]
    foreach ($name in $Names) {
        if ([string]::IsNullOrWhiteSpace($name)) { continue }
        try {
            foreach ($process in @(Get-Process -Name $name -ErrorAction SilentlyContinue)) {
                [void]$ids.Add([int]$process.Id)
            }
        } catch { }
    }
    return @($ids)
}

function Get-AppProcessNames {
    param([string]$ProgId)

    switch -Regex ($ProgId) {
        '^Word\.Application$' { return @('WINWORD') }
        '^(KWPS|WPS)\.' { return @('wps', 'kwps', 'wpscloudsvr') }
        '^Excel\.Application$' { return @('EXCEL') }
        '^(KET|ET)\.' { return @('et', 'ket') }
        '^PowerPoint\.Application$' { return @('POWERPNT') }
        '^(KWPP|WPP)\.' { return @('wpp', 'kwpp') }
        default { return @() }
    }
}

function Initialize-OfficeApp {
    param([hashtable]$Info)

    $app = $Info.App
    $progId = $Info.ProgId

    if ($progId -match '^(Word\.Application|KWPS\.Application|WPS\.Application)$') {
        try { $Info.Old['DisplayAlerts'] = $app.DisplayAlerts; $app.DisplayAlerts = 0 } catch { }
        try { $Info.Old['ScreenUpdating'] = $app.ScreenUpdating; $app.ScreenUpdating = $false } catch { }
        try { $Info.Old['AutomationSecurity'] = $app.AutomationSecurity; $app.AutomationSecurity = 3 } catch { }
    }
    elseif ($progId -match '^(Excel\.Application|KET\.Application|ET\.Application)$') {
        try { $Info.Old['DisplayAlerts'] = $app.DisplayAlerts; $app.DisplayAlerts = $false } catch { }
        try { $Info.Old['ScreenUpdating'] = $app.ScreenUpdating; $app.ScreenUpdating = $false } catch { }
        try { $Info.Old['EnableEvents'] = $app.EnableEvents; $app.EnableEvents = $false } catch { }
        try { $Info.Old['AutomationSecurity'] = $app.AutomationSecurity; $app.AutomationSecurity = 3 } catch { }
        try { $Info.Old['AskToUpdateLinks'] = $app.AskToUpdateLinks; $app.AskToUpdateLinks = $false } catch { }
    }
    elseif ($progId -match '^(PowerPoint\.Application|KWPP\.Application|WPP\.Application)$') {
        try { $Info.Old['DisplayAlerts'] = $app.DisplayAlerts; $app.DisplayAlerts = 1 } catch { }
        try { $Info.Old['AutomationSecurity'] = $app.AutomationSecurity; $app.AutomationSecurity = 3 } catch { }
    }
}

function Get-CachedOfficeApp {
    param([string]$ProgId)

    if ($script:AppCache.ContainsKey($ProgId)) {
        $cached = $script:AppCache[$ProgId]
        if ($cached -and $cached.App) { return $cached }
    }

    $type = [type]::GetTypeFromProgID($ProgId)
    if ($null -eq $type) { return $null }

    $processNames = @(Get-AppProcessNames -ProgId $ProgId)
    $before = @(Get-ProcessIds -Names $processNames)

    $app = $null
    try {
        $app = [Activator]::CreateInstance($type)
    } catch {
        return $null
    }

    Start-Sleep -Milliseconds 350
    $after = @(Get-ProcessIds -Names $processNames)
    $newPids = @($after | Where-Object { $before -notcontains $_ })

    $info = @{
        App = $app
        Owned = ($newPids.Count -gt 0)
        NewPids = @($newPids)
        InitialPids = @($before)
        ProgId = $ProgId
        Old = @{}
    }

    Initialize-OfficeApp -Info $info
    $script:AppCache[$ProgId] = $info
    [void]$script:AppOrder.Add($info)
    return $info
}

function Close-AllOfficeApps {
    foreach ($info in @($script:AppOrder)) {
        $app = $info.App
        if ($null -eq $app) { continue }

        if ($info.Old.ContainsKey('DisplayAlerts')) {
            try { $app.DisplayAlerts = $info.Old['DisplayAlerts'] } catch { }
        }
        if ($info.Old.ContainsKey('ScreenUpdating')) {
            try { $app.ScreenUpdating = $info.Old['ScreenUpdating'] } catch { }
        }
        if ($info.Old.ContainsKey('EnableEvents')) {
            try { $app.EnableEvents = $info.Old['EnableEvents'] } catch { }
        }
        if ($info.Old.ContainsKey('AutomationSecurity')) {
            try { $app.AutomationSecurity = $info.Old['AutomationSecurity'] } catch { }
        }
        if ($info.Old.ContainsKey('AskToUpdateLinks')) {
            try { $app.AskToUpdateLinks = $info.Old['AskToUpdateLinks'] } catch { }
        }

        if ($info.Owned) {
            try { $app.Quit() } catch { }
            Start-Sleep -Milliseconds 300
            foreach ($processId in @($info.NewPids)) {
                try {
                    $process = Get-Process -Id $processId -ErrorAction SilentlyContinue
                    if ($process) { Stop-Process -Id $processId -Force -ErrorAction SilentlyContinue }
                } catch { }
            }
        }
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($app) } catch { }
    }

    $script:AppCache.Clear()
    $script:AppOrder.Clear()
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}

function New-TempCopy {
    param([string]$Path)

    $directory = [System.IO.Path]::GetDirectoryName($Path)
    $extension = [System.IO.Path]::GetExtension($Path)
    $name = 'pinwheel_tmp_' + [Guid]::NewGuid().ToString('N') + $extension
    $temp = [System.IO.Path]::Combine($directory, $name)
    [System.IO.File]::Copy($Path, $temp, $false)
    [void]$script:TempFiles.Add($temp)
    return $temp
}

function Remove-TempFile {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) { return }
    for ($i = 0; $i -lt 8; $i++) {
        try {
            if (Test-Path -LiteralPath $Path) {
                [System.IO.File]::SetAttributes($Path, [System.IO.FileAttributes]::Normal)
                Remove-Item -LiteralPath $Path -Force -ErrorAction Stop
            }
            return
        } catch {
            Start-Sleep -Milliseconds 150
        }
    }
}

function Remove-AllTempFiles {
    foreach ($path in @($script:TempFiles)) {
        Remove-TempFile -Path $path
    }
    $script:TempFiles.Clear()
}

function Remove-OrphanOfficeAutomation {
    foreach ($name in @('WINWORD', 'EXCEL', 'POWERPNT')) {
        $initial = @($script:InitialOfficePids[$name])
        foreach ($process in @(Get-Process -Name $name -ErrorAction SilentlyContinue)) {
            if ($initial -contains $process.Id) { continue }

            try {
                if ($process.StartTime -lt $script:RunStartedAt.AddSeconds(-5)) { continue }
            } catch { }

            $isAutomation = $false
            try {
                $cim = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $process.Id) -ErrorAction SilentlyContinue
                if ($cim -and $cim.CommandLine -match '(?i)/automation') { $isAutomation = $true }
            } catch { }

            if ($isAutomation) {
                try { Stop-Process -Id $process.Id -Force -ErrorAction Stop } catch { }
            }
        }
    }
}

function Get-UniquePdfPath {
    param(
        [string]$Folder,
        [string]$BaseName
    )

    $base = $BaseName
    if ([string]::IsNullOrWhiteSpace($base)) { $base = '转换结果' }

    $candidate = [System.IO.Path]::Combine($Folder, $base + '.pdf')
    if (-not (Test-Path -LiteralPath $candidate)) { return $candidate }

    $stamp = Get-Date -Format 'HHmm'
    $candidate = [System.IO.Path]::Combine($Folder, $base + '_' + $stamp + '.pdf')
    if (-not (Test-Path -LiteralPath $candidate)) { return $candidate }

    $stampSeconds = Get-Date -Format 'HHmmss'
    $candidate = [System.IO.Path]::Combine($Folder, $base + '_' + $stampSeconds + '.pdf')
    if (-not (Test-Path -LiteralPath $candidate)) { return $candidate }

    for ($i = 2; $i -lt 1000; $i++) {
        $candidate = [System.IO.Path]::Combine($Folder, $base + '_' + $stampSeconds + '_' + $i + '.pdf')
        if (-not (Test-Path -LiteralPath $candidate)) { return $candidate }
    }

    throw '无法生成唯一的 PDF 文件名'
}

function Assert-Pdf {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw '未生成 PDF 文件'
    }

    $item = Get-Item -LiteralPath $Path
    if ($item.Length -lt 200) {
        throw '生成的 PDF 文件异常（体积过小）'
    }

    $stream = $null
    try {
        $stream = [System.IO.File]::OpenRead($Path)
        $buffer = New-Object byte[] 5
        $read = $stream.Read($buffer, 0, 5)
        if ($read -lt 5 -or [System.Text.Encoding]::ASCII.GetString($buffer) -ne '%PDF-') {
            throw '生成的 PDF 文件头无效'
        }
    }
    finally {
        if ($stream) { $stream.Dispose() }
    }
}

function Get-WordProgIds {
    param([string]$Extension)

    if ($Extension -in @('.wps', '.wpt')) {
        return @('KWPS.Application', 'WPS.Application', 'Word.Application')
    }
    return @('Word.Application', 'KWPS.Application', 'WPS.Application')
}

function Get-ExcelProgIds {
    param([string]$Extension)

    if ($Extension -in @('.et', '.ett')) {
        return @('KET.Application', 'ET.Application', 'Excel.Application')
    }
    return @('Excel.Application', 'KET.Application', 'ET.Application')
}

function Get-PptProgIds {
    param([string]$Extension)

    if ($Extension -in @('.dps', '.dpt')) {
        return @('KWPP.Application', 'WPP.Application', 'PowerPoint.Application')
    }
    return @('PowerPoint.Application', 'KWPP.Application', 'WPP.Application')
}

function Get-AppWindowProcessId {
    param(
        $App,
        $Document,
        [string]$Kind
    )

    $handle = [IntPtr]::Zero
    try {
        if ($Kind -eq 'word') {
            $handle = [IntPtr][int64]$Document.ActiveWindow.HWND
        } elseif ($Kind -eq 'excel') {
            $handle = [IntPtr][int64]$App.Hwnd
        } elseif ($Kind -eq 'ppt') {
            try {
                $handle = [IntPtr][int64]$Document.Windows.Item(1).HWND
            } catch {
                $handle = [IntPtr][int64]$App.HWND
            }
        }
    } catch { }

    if ($handle -eq [IntPtr]::Zero) { return 0 }
    return [int][Pinwheel.NativeMethods]::GetWindowProcessId($handle)
}

function Convert-OfficeFile {
    param(
        [string]$Path,
        [string]$Kind,
        [string[]]$ProgIds
    )

    $lastError = '没有可用的 Office/WPS 接口'

    foreach ($progId in $ProgIds) {
        $info = Get-CachedOfficeApp -ProgId $progId
        if ($null -eq $info) { continue }

        $pdfPath = $null
        $temp = $null
        $document = $null

        try {
            $folder = [System.IO.Path]::GetDirectoryName($Path)
            $baseName = [System.IO.Path]::GetFileNameWithoutExtension($Path)
            $pdfPath = Get-UniquePdfPath -Folder $folder -BaseName $baseName
            $temp = New-TempCopy -Path $Path
            $app = $info.App

            switch ($Kind) {
                'word' {
                    $document = $app.Documents.Open($temp, $false, $true, $false)
                    $exported = $false
                    try {
                        $document.ExportAsFixedFormat($pdfPath, 17)
                        $exported = Test-Path -LiteralPath $pdfPath
                    } catch { }
                    if (-not $exported) {
                        try {
                            $document.SaveAs($pdfPath, 17)
                            $exported = Test-Path -LiteralPath $pdfPath
                        } catch { }
                    }
                    if (-not $exported) { throw 'Word/WPS 未能导出 PDF' }
                }
                'excel' {
                    $document = $app.Workbooks.Open($temp, 0, $true)
                    try {
                        $document.ExportAsFixedFormat(0, $pdfPath)
                    } catch {
                        throw ('Excel/WPS 导出失败：' + $_.Exception.Message)
                    }
                }
                'ppt' {
                    $document = $app.Presentations.Open($temp, $true, $false, $false)
                    $exported = $false
                    try {
                        $document.ExportAsFixedFormat($pdfPath, 2)
                        $exported = Test-Path -LiteralPath $pdfPath
                    } catch { }
                    if (-not $exported) {
                        try {
                            $document.SaveAs($pdfPath, 32)
                            $exported = Test-Path -LiteralPath $pdfPath
                        } catch { }
                    }
                    if (-not $exported) { throw 'PowerPoint/WPS 未能导出 PDF' }
                }
                default {
                    throw ('未知的文档类型：' + $Kind)
                }
            }

            $windowProcessId = Get-AppWindowProcessId -App $app -Document $document -Kind $Kind
            if ($windowProcessId -gt 0) {
                if ($info.InitialPids -contains $windowProcessId) {
                    $info.Owned = $false
                } elseif ($info.NewPids -contains $windowProcessId) {
                    $info.Owned = $true
                }
            }

            Assert-Pdf -Path $pdfPath
            return [pscustomobject]@{ Ok = $true; Pdf = $pdfPath; Error = $null }
        } catch {
            $lastError = $_.Exception.Message
            if ($pdfPath -and (Test-Path -LiteralPath $pdfPath)) {
                try { Remove-Item -LiteralPath $pdfPath -Force -ErrorAction SilentlyContinue } catch { }
            }
        }
        finally {
            if ($document) {
                try {
                    if ($Kind -eq 'word') { $document.Close(0) }
                    elseif ($Kind -eq 'excel') { $document.Close($false) }
                    elseif ($Kind -eq 'ppt') { $document.Close() }
                } catch { }
                try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($document) } catch { }
            }
            if ($temp) { Remove-TempFile -Path $temp }
        }
    }

    return [pscustomobject]@{ Ok = $false; Pdf = $null; Error = $lastError }
}

function Get-ImageJpegData {
    param([string]$Path)

    Add-Type -AssemblyName System.Drawing
    $jpegCodec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() |
        Where-Object { $_.MimeType -eq 'image/jpeg' } |
        Select-Object -First 1
    if (-not $jpegCodec) { throw '系统缺少 JPEG 编码器' }

    $image = $null
    $bitmap = $null
    $graphics = $null
    $memory = $null

    try {
        $image = [System.Drawing.Image]::FromFile($Path)

        $orientation = 1
        try {
            if ($image.PropertyIdList -contains 0x0112) {
                $orientation = [BitConverter]::ToUInt16($image.GetPropertyItem(0x0112).Value, 0)
            }
        } catch { }

        switch ($orientation) {
            2 { $image.RotateFlip([System.Drawing.RotateFlipType]::RotateNoneFlipX) }
            3 { $image.RotateFlip([System.Drawing.RotateFlipType]::Rotate180FlipNone) }
            4 { $image.RotateFlip([System.Drawing.RotateFlipType]::RotateNoneFlipY) }
            5 { $image.RotateFlip([System.Drawing.RotateFlipType]::Rotate90FlipX) }
            6 { $image.RotateFlip([System.Drawing.RotateFlipType]::Rotate90FlipNone) }
            7 { $image.RotateFlip([System.Drawing.RotateFlipType]::Rotate270FlipX) }
            8 { $image.RotateFlip([System.Drawing.RotateFlipType]::Rotate270FlipNone) }
        }

        $width = $image.Width
        $height = $image.Height
        if ($width -le 0 -or $height -le 0) { throw '图片尺寸无效' }
        if ([int64]$width * [int64]$height -gt 80000000) { throw '图片尺寸过大' }

        $bitmap = New-Object System.Drawing.Bitmap($width, $height, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
        $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
        $graphics.Clear([System.Drawing.Color]::White)
        $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
        $graphics.DrawImage($image, 0, 0, $width, $height)

        $memory = New-Object System.IO.MemoryStream
        $encoderParameters = New-Object System.Drawing.Imaging.EncoderParameters(1)
        $encoderParameters.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter(
            [System.Drawing.Imaging.Encoder]::Quality,
            [int64]92
        )
        $bitmap.Save($memory, $jpegCodec, $encoderParameters)

        return [pscustomobject]@{
            Width = $width
            Height = $height
            Bytes = $memory.ToArray()
        }
    }
    finally {
        if ($memory) { $memory.Dispose() }
        if ($graphics) { $graphics.Dispose() }
        if ($bitmap) { $bitmap.Dispose() }
        if ($image) { $image.Dispose() }
    }
}

function New-ImagePdf {
    param(
        [string[]]$ImagePaths,
        [string]$PdfPath
    )

    Add-Type -AssemblyName System.Drawing
    $images = New-Object System.Collections.ArrayList

    foreach ($path in $ImagePaths) {
        try {
            $data = Get-ImageJpegData -Path $path
            [void]$images.Add($data)
        } catch {
            throw ('无法读取图片「' + [System.IO.Path]::GetFileName($path) + '」：' + $_.Exception.Message)
        }
    }

    if ($images.Count -eq 0) { throw '没有可转换的图片' }

    $pdf = New-Object System.IO.MemoryStream
    try {
        Write-StreamAscii $pdf "%PDF-1.4`n"
        $header = [byte[]](0x25, 0xE2, 0xE3, 0xCF, 0xD3, 0x0A)
        $pdf.Write($header, 0, $header.Length)

        $offsets = @{}
        $pageCount = $images.Count
        $objectCount = 2 + 3 * $pageCount
        $kids = (0..($pageCount - 1) | ForEach-Object { ([string](3 + 3 * $_) + ' 0 R') }) -join ' '

        $offsets[1] = [int64]$pdf.Position
        Write-StreamAscii $pdf "1 0 obj`n<< /Type /Catalog /Pages 2 0 R >>`nendobj`n"

        $offsets[2] = [int64]$pdf.Position
        Write-StreamAscii $pdf ("2 0 obj`n<< /Type /Pages /Kids [{0}] /Count {1} >>`nendobj`n" -f $kids, $pageCount)

        for ($i = 0; $i -lt $pageCount; $i++) {
            $image = $images[$i]
            $pageObject = 3 + 3 * $i
            $contentObject = 4 + 3 * $i
            $imageObject = 5 + 3 * $i

            if ($image.Width -gt $image.Height) {
                $pageWidth = 841.89
                $pageHeight = 595.28
            } else {
                $pageWidth = 595.28
                $pageHeight = 841.89
            }

            $margin = 24.0
            $availableWidth = $pageWidth - 2 * $margin
            $availableHeight = $pageHeight - 2 * $margin
            $scale = [Math]::Min($availableWidth / $image.Width, $availableHeight / $image.Height)
            $drawWidth = $image.Width * $scale
            $drawHeight = $image.Height * $scale
            $drawX = ($pageWidth - $drawWidth) / 2
            $drawY = ($pageHeight - $drawHeight) / 2

            $pageWidthText = Format-PdfNumber $pageWidth
            $pageHeightText = Format-PdfNumber $pageHeight
            $drawWidthText = Format-PdfNumber $drawWidth
            $drawHeightText = Format-PdfNumber $drawHeight
            $drawXText = Format-PdfNumber $drawX
            $drawYText = Format-PdfNumber $drawY

            $offsets[$pageObject] = [int64]$pdf.Position
            Write-StreamAscii $pdf ("{0} 0 obj`n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {1} {2}] /Resources << /XObject << /Im0 {3} 0 R >> >> /Contents {4} 0 R >>`nendobj`n" -f $pageObject, $pageWidthText, $pageHeightText, $imageObject, $contentObject)

            $content = ("q`n{0} 0 0 {1} {2} {3} cm`n/Im0 Do`nQ`n" -f $drawWidthText, $drawHeightText, $drawXText, $drawYText)
            $contentBytes = [System.Text.Encoding]::ASCII.GetBytes($content)

            $offsets[$contentObject] = [int64]$pdf.Position
            Write-StreamAscii $pdf ("{0} 0 obj`n<< /Length {1} >>`nstream`n" -f $contentObject, $contentBytes.Length)
            $pdf.Write($contentBytes, 0, $contentBytes.Length)
            Write-StreamAscii $pdf "`nendstream`nendobj`n"

            $offsets[$imageObject] = [int64]$pdf.Position
            Write-StreamAscii $pdf ("{0} 0 obj`n<< /Type /XObject /Subtype /Image /Width {1} /Height {2} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length {3} >>`nstream`n" -f $imageObject, $image.Width, $image.Height, $image.Bytes.Length)
            $pdf.Write($image.Bytes, 0, $image.Bytes.Length)
            Write-StreamAscii $pdf "`nendstream`nendobj`n"
        }

        $xrefPosition = [int64]$pdf.Position
        Write-StreamAscii $pdf ("xref`n0 {0}`n" -f ($objectCount + 1))
        Write-StreamAscii $pdf "0000000000 65535 f `n"
        for ($objectNumber = 1; $objectNumber -le $objectCount; $objectNumber++) {
            $offset = [int64]$offsets[$objectNumber]
            Write-StreamAscii $pdf ("{0:D10} 00000 n `n" -f $offset)
        }
        Write-StreamAscii $pdf ("trailer`n<< /Size {0} /Root 1 0 R >>`nstartxref`n{1}`n%%EOF`n" -f ($objectCount + 1), $xrefPosition)

        $fileStream = [System.IO.File]::Open($PdfPath, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        try {
            $pdf.Position = 0
            $pdf.CopyTo($fileStream)
            $fileStream.Flush()
        }
        finally {
            $fileStream.Dispose()
        }
    }
    catch {
        if (Test-Path -LiteralPath $PdfPath) {
            try { Remove-Item -LiteralPath $PdfPath -Force -ErrorAction SilentlyContinue } catch { }
        }
        throw
    }
    finally {
        $pdf.Dispose()
    }
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

$script:RunStartedAt = Get-Date
$script:InitialOfficePids = @{}
foreach ($name in @('WINWORD', 'EXCEL', 'POWERPNT')) {
    $script:InitialOfficePids[$name] = @(Get-Process -Name $name -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id)
}

$sourceItems = @()
if ($Files -and $Files.Count -gt 0) {
    $sourceItems = @($Files)
} else {
    $sourceItems = @(Get-CurrentSelection)
}

$paths = @(Resolve-InputFiles -Items $sourceItems)
if ($paths.Count -eq 0) {
    Write-Error '未找到选中的文件。请先在资源管理器或桌面选中文件后再执行。' -ErrorAction Continue
    exit 1
}

$imageFiles = New-Object System.Collections.Generic.List[string]
$wordFiles = New-Object System.Collections.Generic.List[string]
$excelFiles = New-Object System.Collections.Generic.List[string]
$pptFiles = New-Object System.Collections.Generic.List[string]
$pdfFiles = New-Object System.Collections.Generic.List[string]
$unsupportedFiles = New-Object System.Collections.Generic.List[string]

foreach ($path in $paths) {
    $extension = [System.IO.Path]::GetExtension($path).ToLowerInvariant()
    if ($script:ImageExt -contains $extension) {
        [void]$imageFiles.Add($path)
    } elseif ($script:WordExt -contains $extension) {
        [void]$wordFiles.Add($path)
    } elseif ($script:ExcelExt -contains $extension) {
        [void]$excelFiles.Add($path)
    } elseif ($script:PptExt -contains $extension) {
        [void]$pptFiles.Add($path)
    } elseif ($extension -eq '.pdf') {
        [void]$pdfFiles.Add($path)
    } else {
        [void]$unsupportedFiles.Add($path)
    }
}

$success = New-Object System.Collections.Generic.List[string]
$failures = New-Object System.Collections.Generic.List[string]

try {
    foreach ($path in $wordFiles) {
        $extension = [System.IO.Path]::GetExtension($path).ToLowerInvariant()
        $result = Convert-OfficeFile -Path $path -Kind 'word' -ProgIds @(Get-WordProgIds -Extension $extension)
        if ($result.Ok) {
            [void]$success.Add($result.Pdf)
        } else {
            [void]$failures.Add(([System.IO.Path]::GetFileName($path) + '：' + $result.Error))
        }
    }

    foreach ($path in $excelFiles) {
        $extension = [System.IO.Path]::GetExtension($path).ToLowerInvariant()
        $result = Convert-OfficeFile -Path $path -Kind 'excel' -ProgIds @(Get-ExcelProgIds -Extension $extension)
        if ($result.Ok) {
            [void]$success.Add($result.Pdf)
        } else {
            [void]$failures.Add(([System.IO.Path]::GetFileName($path) + '：' + $result.Error))
        }
    }

    foreach ($path in $pptFiles) {
        $extension = [System.IO.Path]::GetExtension($path).ToLowerInvariant()
        $result = Convert-OfficeFile -Path $path -Kind 'ppt' -ProgIds @(Get-PptProgIds -Extension $extension)
        if ($result.Ok) {
            [void]$success.Add($result.Pdf)
        } else {
            [void]$failures.Add(([System.IO.Path]::GetFileName($path) + '：' + $result.Error))
        }
    }

    if ($imageFiles.Count -gt 0) {
        $imagePdf = $null
        try {
            $firstImage = $imageFiles[0]
            $imageFolder = [System.IO.Path]::GetDirectoryName($firstImage)
            $imageBase = [System.IO.Path]::GetFileNameWithoutExtension($firstImage)
            if ([string]::IsNullOrWhiteSpace($imageBase)) { $imageBase = '图片合并' }
            if ($imageFiles.Count -gt 1) { $imageBase = $imageBase + '_合并' }

            $imagePdf = Get-UniquePdfPath -Folder $imageFolder -BaseName $imageBase
            New-ImagePdf -ImagePaths @($imageFiles) -PdfPath $imagePdf
            Assert-Pdf -Path $imagePdf
            [void]$success.Add($imagePdf)
        } catch {
            if ($imagePdf -and (Test-Path -LiteralPath $imagePdf)) {
                try { Remove-Item -LiteralPath $imagePdf -Force -ErrorAction SilentlyContinue } catch { }
            }
            [void]$failures.Add(('图片合并：' + $_.Exception.Message))
        }
    }

    foreach ($path in $unsupportedFiles) {
        [void]$failures.Add(([System.IO.Path]::GetFileName($path) + '：不支持的文件类型'))
    }
}
catch {
    [void]$failures.Add(('执行失败：' + $_.Exception.Message))
}
finally {
    Close-AllOfficeApps
    Remove-OrphanOfficeAutomation
    Remove-AllTempFiles
}

if ($failures.Count -gt 0) {
    $message = ('转换完成 {0} 个，失败 {1} 个：{2}' -f $success.Count, $failures.Count, ($failures -join '；'))
    Write-Error $message -ErrorAction Continue
    exit 1
}

if ($success.Count -eq 0) {
    if ($pdfFiles.Count -gt 0 -and $unsupportedFiles.Count -eq 0) {
        Write-Output '选中的文件已经是 PDF，无需转换'
        exit 0
    }
    Write-Error '没有可转换的文件。' -ErrorAction Continue
    exit 1
}

if ($imageFiles.Count -gt 1 -and $wordFiles.Count + $excelFiles.Count + $pptFiles.Count -eq 0) {
    Write-Output ('已将 {0} 张图片合并为 PDF：{1}' -f $imageFiles.Count, [System.IO.Path]::GetFileName($success[0]))
} elseif ($success.Count -eq 1) {
    Write-Output ('已转换为 PDF：' + [System.IO.Path]::GetFileName($success[0]))
} else {
    Write-Output ('已转换 {0} 个文件为 PDF' -f $success.Count)
}

exit 0
