﻿$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class WinApi {
    [DllImport("user32.dll")] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
}
'@
[WinApi]::keybd_event(0xB3, 0, 0, [UIntPtr]::Zero)
[WinApi]::keybd_event(0xB3, 0, 2, [UIntPtr]::Zero)
