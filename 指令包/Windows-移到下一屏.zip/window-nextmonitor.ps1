﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class WinApi {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
}
'@
$h = [WinApi]::GetForegroundWindow()
if ($h -eq [IntPtr]::Zero) { exit 1 }
$screens = [System.Windows.Forms.Screen]::AllScreens
if ($screens.Length -lt 2) { exit 1 }
$current = [System.Windows.Forms.Screen]::FromHandle($h)
$idx = [Array]::IndexOf($screens, $current)
$next = $screens[($idx + 1) % $screens.Length]
$rect = New-Object WinApi+RECT
[WinApi]::GetWindowRect($h, [ref]$rect) | Out-Null
$w = $rect.Right - $rect.Left
$ht = $rect.Bottom - $rect.Top
$x = $next.WorkingArea.Left + ($rect.Left - $current.WorkingArea.Left)
$y = $next.WorkingArea.Top + ($rect.Top - $current.WorkingArea.Top)
[WinApi]::SetWindowPos($h, [IntPtr]::Zero, $x, $y, $w, $ht, 0x4 -bor 0x10) | Out-Null
