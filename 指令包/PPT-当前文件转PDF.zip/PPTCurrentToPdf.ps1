﻿# Pinwheel 指令：把当前正在编辑的 Office 文件导出为 PDF。
# PPT 会被构建脚本替换为 Word / Excel / PPT。

$AppKind = 'PPT'

$ErrorActionPreference = 'Stop'

try {
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [Console]::OutputEncoding = $utf8NoBom
    $OutputEncoding = $utf8NoBom
} catch { }

if (-not ('PinwheelOfficeNative' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace PinwheelOffice {
    public static class Native {
        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool EnumChildWindows(IntPtr hWndParent, EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

        [DllImport("user32.dll")]
        private static extern IntPtr GetAncestor(IntPtr hWnd, uint gaFlags);

        [DllImport("oleacc.dll")]
        private static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint dwId, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object ppvObject);

        private static Guid IID_IDispatch = new Guid("00020400-0000-0000-C000-000000000046");

        private static string ClassName(IntPtr hWnd) {
            StringBuilder builder = new StringBuilder(256);
            GetClassName(hWnd, builder, builder.Capacity);
            return builder.ToString();
        }

        public static IntPtr FindOfficeMainWindow(string className) {
            IntPtr foreground = GetForegroundWindow();
            if (foreground != IntPtr.Zero) {
                IntPtr root = GetAncestor(foreground, 2);
                if (root != IntPtr.Zero && ClassName(root) == className) {
                    return root;
                }
            }

            IntPtr found = IntPtr.Zero;
            EnumWindows(delegate(IntPtr hWnd, IntPtr lParam) {
                if (IsWindowVisible(hWnd) && ClassName(hWnd) == className) {
                    found = hWnd;
                    return false;
                }
                return true;
            }, IntPtr.Zero);
            return found;
        }

        public static IntPtr FindChildByClass(IntPtr parent, string className) {
            IntPtr found = IntPtr.Zero;
            EnumChildWindows(parent, delegate(IntPtr hWnd, IntPtr lParam) {
                if (ClassName(hWnd) == className) {
                    found = hWnd;
                    return false;
                }
                return true;
            }, IntPtr.Zero);
            return found;
        }

        public static object GetNativeObject(IntPtr hWnd) {
            object result;
            int hr = AccessibleObjectFromWindow(hWnd, 0xFFFFFFF0, ref IID_IDispatch, out result);
            if (hr != 0) { return null; }
            return result;
        }
    }
}
'@
}

function Get-UniquePdfPath {
    param(
        [string]$Folder,
        [string]$BaseName
    )

    $base = $BaseName
    if ([string]::IsNullOrWhiteSpace($base)) { $base = '当前文件' }

    $candidate = [System.IO.Path]::Combine($Folder, $base + '.pdf')
    if (-not (Test-Path -LiteralPath $candidate)) { return $candidate }

    $stamp = Get-Date -Format 'HHmm'
    $candidate = [System.IO.Path]::Combine($Folder, $base + '_' + $stamp + '.pdf')
    if (-not (Test-Path -LiteralPath $candidate)) { return $candidate }

    $stampSeconds = Get-Date -Format 'HHmmss'
    $candidate = [System.IO.Path]::Combine($Folder, $base + '_' + $stampSeconds + '.pdf')
    if (-not (Test-Path -LiteralPath $candidate)) { return $candidate }

    for ($i = 2; $i -lt 1000; $i++) {
        $candidate = [System.IO.Path]::Combine($Folder, $base + '_' + $stampSeconds + '_' + $i + '.pdf')
        if (-not (Test-Path -LiteralPath $candidate)) { return $candidate }
    }

    throw '无法生成唯一的 PDF 文件名'
}

function Assert-Pdf {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw '未生成 PDF 文件'
    }

    $item = Get-Item -LiteralPath $Path
    if ($item.Length -lt 200) {
        throw '生成的 PDF 文件异常（体积过小）'
    }

    $stream = $null
    try {
        $stream = [System.IO.File]::OpenRead($Path)
        $buffer = New-Object byte[] 5
        $read = $stream.Read($buffer, 0, 5)
        if ($read -lt 5 -or [System.Text.Encoding]::ASCII.GetString($buffer) -ne '%PDF-') {
            throw '生成的 PDF 文件头无效'
        }
    }
    finally {
        if ($stream) { $stream.Dispose() }
    }
}

function Get-DesktopFolder {
    $desktop = [Environment]::GetFolderPath('Desktop')
    if ([string]::IsNullOrWhiteSpace($desktop) -or -not (Test-Path -LiteralPath $desktop -PathType Container)) {
        throw '找不到桌面文件夹。'
    }
    return $desktop
}

function Get-OfficeApplication {
    param(
        [ValidateSet('Word', 'Excel', 'PPT')]
        [string]$Kind
    )

    $mainClass = @{ Word = 'OpusApp'; Excel = 'XLMAIN'; PPT = 'PPTFrameClass' }[$Kind]
    $childClass = @{ Word = '_WwG'; Excel = 'EXCEL7'; PPT = 'mdiClass' }[$Kind]
    $displayName = @{ Word = 'Word'; Excel = 'Excel'; PPT = 'PowerPoint' }[$Kind]

    $mainWindow = [PinwheelOffice.Native]::FindOfficeMainWindow($mainClass)
    if ($mainWindow -eq [IntPtr]::Zero) {
        throw ('未检测到正在运行的 ' + $displayName + ' 窗口，请先打开要转换的文件。')
    }

    # 用当前窗口自己的子窗口取 Automation 对象，避免 GetActiveObject 选到另一个 Office 实例。
    $childWindow = [PinwheelOffice.Native]::FindChildByClass($mainWindow, $childClass)
    if ($childWindow -eq [IntPtr]::Zero) {
        throw ('当前没有打开的 ' + $displayName + ' 文件。')
    }

    $nativeObject = [PinwheelOffice.Native]::GetNativeObject($childWindow)
    if ($null -eq $nativeObject) {
        throw ('无法连接到当前的 ' + $displayName + ' 窗口。')
    }

    $app = $null
    try { $app = $nativeObject.Application } catch { }
    if ($null -eq $app) { $app = $nativeObject }
    if ($null -eq $app) {
        throw ('无法获取 ' + $displayName + ' 的应用程序对象。')
    }

    return $app
}

function Get-SourceInfo {
    param(
        $Document,
        [string]$DisplayName
    )

    if ($null -eq $Document) {
        throw ('当前没有打开的 ' + $DisplayName + '。')
    }

    $path = $null
    try { $path = [string]$Document.Path } catch { }
    if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path -PathType Container)) {
        throw '当前文件尚未保存，请先保存后再执行。'
    }

    $fullName = $null
    try { $fullName = [string]$Document.FullName } catch { }
    if ([string]::IsNullOrWhiteSpace($fullName) -or -not (Test-Path -LiteralPath $fullName -PathType Leaf)) {
        throw '当前文件尚未保存，请先保存后再执行。'
    }

    return [pscustomobject]@{
        FullName = $fullName
        Folder = [System.IO.Path]::GetDirectoryName($fullName)
        BaseName = [System.IO.Path]::GetFileNameWithoutExtension($fullName)
    }
}

function Save-WordAsPdf {
    $app = $null
    $document = $null
    $pdfPath = $null
    $oldAlerts = $null

    try {
        $app = Get-OfficeApplication -Kind 'Word'
        try { $document = $app.ActiveDocument } catch { }
        if ($null -eq $document) { throw '当前没有打开的 Word 文档。' }

        $source = Get-SourceInfo -Document $document -DisplayName 'Word 文档'
        $pdfPath = Get-UniquePdfPath -Folder (Get-DesktopFolder) -BaseName $source.BaseName

        try {
            $oldAlerts = $app.DisplayAlerts
            $app.DisplayAlerts = 0
        } catch { }

        # 只导出，不 Save / SaveAs，当前文档的路径和未保存状态都不变。
        $document.ExportAsFixedFormat($pdfPath, 17)
        Assert-Pdf -Path $pdfPath
        return [System.IO.Path]::GetFileName($pdfPath)
    }
    catch {
        if ($pdfPath -and (Test-Path -LiteralPath $pdfPath)) {
            try { Remove-Item -LiteralPath $pdfPath -Force -ErrorAction SilentlyContinue } catch { }
        }
        throw
    }
    finally {
        if ($null -ne $oldAlerts -and $app) {
            try { $app.DisplayAlerts = $oldAlerts } catch { }
        }
        if ($document) {
            try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($document) } catch { }
        }
        if ($app) {
            try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($app) } catch { }
        }
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
    }
}

function Save-ExcelAsPdf {
    $app = $null
    $workbook = $null
    $pdfPath = $null
    $oldAlerts = $null

    try {
        $app = Get-OfficeApplication -Kind 'Excel'
        try { $workbook = $app.ActiveWorkbook } catch { }
        if ($null -eq $workbook) { throw '当前没有打开的 Excel 工作簿。' }

        $source = Get-SourceInfo -Document $workbook -DisplayName 'Excel 工作簿'
        $pdfPath = Get-UniquePdfPath -Folder (Get-DesktopFolder) -BaseName $source.BaseName

        try {
            $oldAlerts = $app.DisplayAlerts
            $app.DisplayAlerts = $false
        } catch { }

        # 导出整个工作簿（含所有工作表），不 Save，不改变当前工作簿。
        $workbook.ExportAsFixedFormat(0, $pdfPath)
        Assert-Pdf -Path $pdfPath
        return [System.IO.Path]::GetFileName($pdfPath)
    }
    catch {
        if ($pdfPath -and (Test-Path -LiteralPath $pdfPath)) {
            try { Remove-Item -LiteralPath $pdfPath -Force -ErrorAction SilentlyContinue } catch { }
        }
        throw
    }
    finally {
        if ($null -ne $oldAlerts -and $app) {
            try { $app.DisplayAlerts = $oldAlerts } catch { }
        }
        if ($workbook) {
            try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($workbook) } catch { }
        }
        if ($app) {
            try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($app) } catch { }
        }
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
    }
}

function Save-PptAsPdf {
    $app = $null
    $presentation = $null
    $copy = $null
    $pdfPath = $null
    $tempPptx = $null
    $oldAlerts = $null

    try {
        $app = Get-OfficeApplication -Kind 'PPT'
        try { $presentation = $app.ActivePresentation } catch { }
        if ($null -eq $presentation) { throw '当前没有打开的 PowerPoint 演示文稿。' }

        $source = Get-SourceInfo -Document $presentation -DisplayName 'PowerPoint 演示文稿'
        $pdfPath = Get-UniquePdfPath -Folder (Get-DesktopFolder) -BaseName $source.BaseName

        # 先把当前编辑状态保存为同目录下的临时 PPTX 副本（保留未保存修改），
        # 再用副本另存为 PDF，原演示文稿的路径和内容都不变。
        $tempPptx = [System.IO.Path]::Combine($source.Folder, 'pinwheel_ppt_' + [Guid]::NewGuid().ToString('N') + '.pptx')

        try {
            $oldAlerts = $app.DisplayAlerts
            $app.DisplayAlerts = 1
        } catch { }

        $presentation.SaveCopyAs($tempPptx, 24)
        if (-not (Test-Path -LiteralPath $tempPptx -PathType Leaf)) {
            throw '无法创建临时演示文稿副本'
        }

        $copy = $app.Presentations.Open($tempPptx, $false, $false, $false)
        $copy.SaveAs($pdfPath, 32)
        Assert-Pdf -Path $pdfPath
        return [System.IO.Path]::GetFileName($pdfPath)
    }
    catch {
        if ($pdfPath -and (Test-Path -LiteralPath $pdfPath)) {
            try { Remove-Item -LiteralPath $pdfPath -Force -ErrorAction SilentlyContinue } catch { }
        }
        throw
    }
    finally {
        if ($copy) {
            try { $copy.Close() } catch { }
            try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($copy) } catch { }
        }
        if ($presentation) {
            try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($presentation) } catch { }
        }
        if ($null -ne $oldAlerts -and $app) {
            try { $app.DisplayAlerts = $oldAlerts } catch { }
        }
        if ($app) {
            try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($app) } catch { }
        }
        if ($tempPptx -and (Test-Path -LiteralPath $tempPptx)) {
            try {
                Remove-Item -LiteralPath $tempPptx -Force -ErrorAction Stop
            } catch {
                Start-Sleep -Milliseconds 250
                try { Remove-Item -LiteralPath $tempPptx -Force -ErrorAction SilentlyContinue } catch { }
            }
        }
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
    }
}

try {
    $savedName = $null

    switch ($AppKind) {
        'Word' { $savedName = Save-WordAsPdf }
        'Excel' { $savedName = Save-ExcelAsPdf }
        'PPT' { $savedName = Save-PptAsPdf }
        default { throw '未知的应用类型。' }
    }

    Write-Output ('已保存 PDF：' + $savedName)
    exit 0
}
catch {
    Write-Error ('执行失败：' + $_.Exception.Message) -ErrorAction Continue
    exit 1
}
