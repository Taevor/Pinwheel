﻿param(
    [Parameter(Mandatory = $true)]
    [string]$ListFile
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$results = @()
$paths = [System.IO.File]::ReadAllLines($ListFile, [System.Text.Encoding]::UTF8)
foreach ($p in $paths) {
    $p = $p.Trim()
    if ([string]::IsNullOrWhiteSpace($p)) { continue }

    try {
        $pfc = New-Object System.Drawing.Text.PrivateFontCollection
        $pfc.AddFontFile($p)
        $name = $null
        if ($pfc.Families.Length -gt 0) {
            $name = $pfc.Families[0].Name
        }
        $pfc.Dispose()
        $results += [pscustomobject]@{ Path = $p; Name = $name; Error = $null }
    }
    catch {
        $results += [pscustomobject]@{ Path = $p; Name = $null; Error = $_.Exception.Message }
    }
}

$results | ConvertTo-Json -Compress -Depth 3
