﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$logFile = Join-Path $PSScriptRoot 'run.log'
$helper = Join-Path $PSScriptRoot 'read-font-name.ps1'

function Write-Diag([string]$m) {
    try { Add-Content -LiteralPath $logFile -Value ((Get-Date -Format 'HH:mm:ss.fff') + ' ' + $m) -Encoding UTF8 } catch { }
}

function Get-SelectedFiles {
    $shell = New-Object -ComObject Shell.Application
    $selected = @()
    $focused = @()
    foreach ($win in $shell.Windows()) {
        try {
            if ($null -eq $win.Document) { continue }
            $sel = $win.Document.SelectedItems()
            if ($null -ne $sel -and $sel.Count -gt 0) {
                foreach ($item in $sel) { $selected += $item.Path }
            }
            $focus = $win.Document.FocusedItem
            if ($null -ne $focus -and -not [string]::IsNullOrWhiteSpace($focus.Path)) {
                $focused += $focus.Path
            }
        }
        catch { }
    }

    if ($selected.Count -gt 0) { return $selected }
    foreach ($f in $focused) {
        if (Test-Path -LiteralPath $f -PathType Leaf) { return @($f) }
    }
    return @()
}

function Get-SafeName([string]$name) {
    $invalid = [System.IO.Path]::GetInvalidFileNameChars()
    foreach ($ch in $invalid) {
        $name = $name.Replace([string]$ch, '')
    }
    $name = $name.Trim()
    if ([string]::IsNullOrWhiteSpace($name)) { return $null }
    return $name
}

Write-Diag '脚本开始'

$extensions = @('.ttf', '.otf', '.ttc')
$raw = @(Get-SelectedFiles)
Write-Diag ('原始选中=' + ($raw -join ' | '))
$files = @($raw | Where-Object { $extensions -contains ([System.IO.Path]::GetExtension($_).ToLowerInvariant()) })
Write-Diag ('过滤后=' + ($files -join ' | '))

if ($files.Count -eq 0) {
    Write-Diag '未取到字体，弹出文件选择框'
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = '字体文件 (*.ttf;*.otf;*.ttc)|*.ttf;*.otf;*.ttc|所有文件 (*.*)|*.*'
    $dlg.Multiselect = $true
    $dlg.Title = '选择要按字体名重命名的字体文件'
    if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        Write-Diag '用户取消了选择'
        exit 1
    }
    $files = @($dlg.FileNames)
    Write-Diag ('手动选择=' + ($files -join ' | '))
}

$listFile = Join-Path $env:TEMP ('PinwheelFonts_' + [System.Guid]::NewGuid().ToString('N') + '.txt')
$files | ForEach-Object { [System.IO.File]::AppendAllText($listFile, $_ + [Environment]::NewLine, [System.Text.Encoding]::UTF8) }

$renamed = @()
$failed = @()
$skipped = @()

try {
    $json = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $helper -ListFile $listFile
    $parsed = ConvertFrom-Json ($json -join '')
    if ($null -eq $parsed) { $parsed = @() }
    if ($parsed -isnot [System.Array]) { $parsed = @($parsed) }

    foreach ($item in $parsed) {
        $path = [string]$item.Path
        $fontName = [string]$item.Name
        if ([string]::IsNullOrWhiteSpace($fontName)) {
            $failed += $path
            continue
        }

        $safe = Get-SafeName $fontName
        if ($null -eq $safe) {
            $failed += $path
            continue
        }

        $dir = [System.IO.Path]::GetDirectoryName($path)
        $ext = [System.IO.Path]::GetExtension($path).ToLowerInvariant()
        $target = Join-Path $dir ($safe + $ext)

        $counter = 2
        while ((Test-Path -LiteralPath $target) -and -not [string]::Equals($target, $path, [System.StringComparison]::OrdinalIgnoreCase)) {
            $target = Join-Path $dir ($safe + " ($counter)" + $ext)
            $counter++
        }

        if ([string]::Equals($target, $path, [System.StringComparison]::OrdinalIgnoreCase)) {
            $skipped += $path
            continue
        }

        try {
            Rename-Item -LiteralPath $path -NewName (Split-Path -Leaf $target)
            $renamed += (Split-Path -Leaf $target)
        }
        catch {
            $failed += $path
        }
    }
}
finally {
    if (Test-Path -LiteralPath $listFile) { Remove-Item -LiteralPath $listFile -Force }
}

Write-Diag ('结果: 成功=' + $renamed.Count + ' 失败=' + $failed.Count + ' 已同名=' + $skipped.Count)

if ($renamed.Count -eq 0 -and $failed.Count -gt 0) {
    Write-Error '未能成功重命名，请确认文件是有效的字体文件且未被占用。'
    exit 1
}

$msg = '成功重命名 ' + $renamed.Count + ' 个'
if ($skipped.Count -gt 0) { $msg += '，' + $skipped.Count + ' 个已是正确名称' }
if ($failed.Count -gt 0) { $msg += '，' + $failed.Count + ' 个失败' }
Write-Output $msg
