﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$logFile = Join-Path $PSScriptRoot 'run.log'

function Write-Diag([string]$m) {
    try { Add-Content -LiteralPath $logFile -Value ((Get-Date -Format 'HH:mm:ss.fff') + ' ' + $m) -Encoding UTF8 } catch { }
}

$app = $null
try { $app = [System.Runtime.InteropServices.Marshal]::GetActiveObject('Illustrator.Application') } catch { }

if ($null -eq $app) {
    Write-Diag '未检测到正在运行的 Illustrator'
    Write-Error '未检测到运行中的 Illustrator，请先打开文档并选中群组。'
    exit 1
}

try {
    $js = @'
var doc;
if (app.documents.length === 0) {
    throw new Error('当前没有打开的 Illustrator 文档');
}
doc = app.activeDocument;
var sel = doc.selection;
if (!sel || sel.length === 0) {
    throw new Error('请先选中要加描边的群组');
}

// 群组对象本身没有 stroked/strokeWidth 属性，不能直接给群组加描边。
// 参考“批量加边框”脚本的做法：取选中对象（含群组内所有子对象）的整体边界，
// 在边界处画一个 0.1pt 黑色描边、无填充的矩形，只描外框，不动群组里的内容。
function collectLeafItems(obj, out) {
    try {
        if (obj.constructor && obj.constructor.name === 'GroupItem') {
            if (obj.clipped) {
                if (obj.pageItems.length > 0) {
                    out.push(obj.pageItems[0]);
                }
                return;
            }
            var n = obj.pageItems.length;
            for (var i = 0; i < n; i += 1) {
                collectLeafItems(obj.pageItems[i], out);
            }
            return;
        }
    } catch (e) {}
    out.push(obj);
}

function getBounds(obj) {
    var items = [];
    collectLeafItems(obj, items);
    if (items.length === 0) {
        throw new Error('无法读取选中对象的边界');
    }
    var b = items[0].geometricBounds;
    var left = b[0];
    var top = b[1];
    var right = b[2];
    var bottom = b[3];
    for (var j = 1; j < items.length; j += 1) {
        b = items[j].geometricBounds;
        if (b[0] < left) { left = b[0]; }
        if (b[1] > top) { top = b[1]; }
        if (b[2] > right) { right = b[2]; }
        if (b[3] < bottom) { bottom = b[3]; }
    }
    return [left, top, right, bottom];
}

function addBorder(obj) {
    var b = getBounds(obj);
    var left = b[0];
    var top = b[1];
    var right = b[2];
    var bottom = b[3];
    var width = right - left;
    var height = top - bottom;

    var rect = doc.activeLayer.pathItems.rectangle(top, left, width, height);
    rect.stroked = true;
    rect.strokeWidth = 0.1;

    var black = new CMYKColor();
    black.cyan = 0;
    black.magenta = 0;
    black.yellow = 0;
    black.black = 100;
    rect.strokeColor = black;

    rect.filled = false;
    rect.fillColor = new NoColor();
    rect.selected = true;
}

var selectedItems = [];
for (var k = 0; k < sel.length; k += 1) {
    selectedItems.push(sel[k]);
}

for (var m = 0; m < selectedItems.length; m += 1) {
    addBorder(selectedItems[m]);
}
app.redraw();
'OK:' + selectedItems.length;
'@
    $result = $app.DoJavaScript($js)
    Write-Diag ('描边完成，返回：' + $result)
    Write-Output '已给选中的群组本身添加 0.1pt 描边'
}
catch {
    Write-Diag ('添加描边失败: ' + $_.Exception.Message)
    Write-Error ('添加描边失败：' + $_.Exception.Message)
    exit 1
}
