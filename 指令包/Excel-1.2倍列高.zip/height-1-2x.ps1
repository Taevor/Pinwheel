﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$logFile = Join-Path $PSScriptRoot 'run.log'

function Write-Diag([string]$m) {
    try { Add-Content -LiteralPath $logFile -Value ((Get-Date -Format 'HH:mm:ss.fff') + ' ' + $m) -Encoding UTF8 } catch { }
}

$app = $null
foreach ($progId in @('Excel.Application', 'KET.Application')) {
    try {
        $app = [System.Runtime.InteropServices.Marshal]::GetActiveObject($progId)
        if ($null -ne $app) { break }
    }
    catch { }
}

if ($null -eq $app) {
    Write-Diag '未检测到正在运行的 Excel / WPS'
    Write-Error '未检测到运行中的 Excel 或 WPS，请先打开表格。'
    exit 1
}

try {
    $count = 0
    foreach ($row in $app.Selection.Rows) {
        $row.RowHeight = [math]::Round($row.RowHeight * 1.2, 2)
        $count++
    }
    Write-Diag ('已把 ' + $count + ' 行行高放大到 1.2 倍')
    Write-Output "已将 $($count) 行行高放大到 1.2 倍"
}
catch {
    Write-Diag ('调整行高失败: ' + $_.Exception.Message)
    Write-Error ('调整行高失败：' + $_.Exception.Message)
    exit 1
}
