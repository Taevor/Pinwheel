﻿$ErrorActionPreference = 'SilentlyContinue'
$app = $null
try { $app = [System.Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application') } catch { }
if ($null -eq $app) {
    try { $app = [System.Runtime.InteropServices.Marshal]::GetActiveObject('KET.Application') } catch { }
}
if ($null -ne $app) {
    $app.Selection.EntireColumn.AutoFit() | Out-Null
    $app.Selection.EntireRow.AutoFit() | Out-Null
}
