﻿$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class WinApi {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
}
'@
$h = [WinApi]::GetForegroundWindow()
if ($h -eq [IntPtr]::Zero) { exit 1 }
$topmost = ([WinApi]::GetWindowLong($h, -20) -band 0x8) -ne 0
$after = if ($topmost) { [IntPtr](-2) } else { [IntPtr](-1) }
[WinApi]::SetWindowPos($h, $after, 0, 0, 0, 0, 0x2 -bor 0x1 -bor 0x10) | Out-Null
