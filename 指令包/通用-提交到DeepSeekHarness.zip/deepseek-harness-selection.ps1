﻿$ErrorActionPreference = 'Stop'
$log = Join-Path $PSScriptRoot 'run.log'

function Write-Log([string]$msg) {
    try {
        Add-Content -LiteralPath $log -Value ("{0:HH:mm:ss} {1}" -f (Get-Date), $msg) -Encoding UTF8
    } catch { }
}

try {
    Write-Log '开始执行'
    Add-Type -AssemblyName System.Windows.Forms

    # 1. 复制当前选中的文字
    [System.Windows.Forms.SendKeys]::SendWait('^c')
    Start-Sleep -Milliseconds 150

    $text = [System.Windows.Forms.Clipboard]::GetText()
    $text = $text.Trim()
    Write-Log "剪贴板内容长度: $($text.Length)"

    if ([string]::IsNullOrEmpty($text)) {
        Write-Log '剪贴板为空，退出'
        Write-Error '未读取到选中的文字，请先选中要提交的内容。'
        exit 1
    }

    # 2. 把选中文字写进临时文件，避免命令行转义问题
    $tmpDir = Join-Path $env:TEMP 'PinwheelDsh'
    if (-not (Test-Path -LiteralPath $tmpDir)) {
        New-Item -ItemType Directory -Path $tmpDir -Force | Out-Null
    }

    $inputFile = Join-Path $tmpDir ('input-' + [guid]::NewGuid().ToString('N') + '.txt')
    $resultFile = Join-Path $tmpDir ('result-' + [guid]::NewGuid().ToString('N') + '.txt')
    [System.IO.File]::WriteAllText($inputFile, $text, [System.Text.UTF8Encoding]::new($false))

    # 3. 生成后台 runner 脚本（隐藏窗口运行，不弹黑控制台）
    $runnerBody = @'
$ErrorActionPreference = 'Continue'
$inputFile = '__INPUT_FILE__'
$resultFile = '__RESULT_FILE__'
$diagLog = Join-Path $env:TEMP 'PinwheelDsh\run.log'

function Write-Diag([string]$m) {
    try { Add-Content -LiteralPath $diagLog -Value ((Get-Date -Format 'HH:mm:ss.fff') + ' ' + $m) -Encoding UTF8 } catch { }
}

function Show-Notification([string]$title, [string]$text, [string]$kind = 'info') {
    if ($pinwheelApp -and (Test-Path -LiteralPath $pinwheelApp)) {
        & $pinwheelApp notify $title $text $kind
    }
}

try {
    Set-Location -LiteralPath $env:USERPROFILE

    $text = Get-Content -LiteralPath $inputFile -Raw -Encoding UTF8
    $text = $text.Trim()
    if ([string]::IsNullOrEmpty($text)) {
        Show-Notification 'DeepSeek Harness' '未读到选中的文字' 'warning'
        exit 1
    }

    # 找 dsh 命令：优先 PATH 里的，再找 npm 全局目录
    $dsh = Get-Command dsh -ErrorAction SilentlyContinue
    if (-not $dsh) {
        $candidates = @(
            (Join-Path $env:APPDATA 'npm\dsh.cmd'),
            (Join-Path $env:APPDATA 'npm\dsh.ps1'),
            (Join-Path $env:APPDATA 'npm\dsh')
        )
        foreach ($c in $candidates) {
            if (Test-Path -LiteralPath $c) { $dsh = $c; break }
        }
    }
    if (-not $dsh) {
        Write-Diag '没有找到 dsh 命令'
        Show-Notification 'DeepSeek Harness' '未找到 dsh 命令，请先安装 DeepSeek Harness' 'error'
        exit 1
    }

    $dshPath = if ($dsh -is [string]) { $dsh } elseif ($dsh.Source) { $dsh.Source } else { 'dsh' }
    Write-Diag ('使用的 dsh: ' + $dshPath)

    # 双引号转成单引号，避免 PowerShell 传参时被截断
    $safeText = $text -replace '"', "'"

    Write-Diag '开始执行 dsh headless'
    $raw = & $dshPath --profile headless $safeText 2>&1
    $exitCode = $LASTEXITCODE
    Write-Diag ('dsh 退出码: ' + $exitCode)

    $body = '任务内容：' + [Environment]::NewLine + $safeText + [Environment]::NewLine + [Environment]::NewLine + '结果：' + [Environment]::NewLine + ($raw | Out-String)
    [System.IO.File]::WriteAllText($resultFile, $body, [System.Text.UTF8Encoding]::new($true))

    if ($exitCode -eq 0) {
        if ($pinwheelApp -and (Test-Path -LiteralPath $pinwheelApp)) {
            & $pinwheelApp notify 'DeepSeek Harness' '任务已执行完成' 'success'
        }
    } else {
        if ($pinwheelApp -and (Test-Path -LiteralPath $pinwheelApp)) {
            & $pinwheelApp notify 'DeepSeek Harness' '任务执行失败，请看结果' 'error'
        }
    }

    Start-Process -FilePath 'notepad.exe' -ArgumentList ('"' + $resultFile + '"')
    exit 0
}
catch {
    Write-Diag ('执行异常: ' + $_.Exception.Message)
    try {
        [System.IO.File]::AppendAllText($resultFile, ([Environment]::NewLine + '执行异常：' + $_.Exception.Message), [System.Text.UTF8Encoding]::new($true))
    } catch { }
    if ($pinwheelApp -and (Test-Path -LiteralPath $pinwheelApp)) {
        & $pinwheelApp notify 'DeepSeek Harness' ('任务执行失败：' + $_.Exception.Message) 'error'
    }
    try { Start-Process -FilePath 'notepad.exe' -ArgumentList ('"' + $resultFile + '"') } catch { }
    exit 1
}
'@
    $runnerBody = $runnerBody.Replace('__INPUT_FILE__', $inputFile).Replace('__RESULT_FILE__', $resultFile)
    if ($env:PINWHEEL_APP) {
        $runnerBody = '$pinwheelApp = "' + ($env:PINWHEEL_APP -replace '\\', '\\') + '"' + [Environment]::NewLine + $runnerBody
    } else {
        $runnerBody = '$pinwheelApp = $null' + [Environment]::NewLine + $runnerBody
    }
    $runnerFile = Join-Path $tmpDir ('runner-' + [guid]::NewGuid().ToString('N') + '.ps1')
    [System.IO.File]::WriteAllText($runnerFile, $runnerBody, [System.Text.UTF8Encoding]::new($true))

    Write-Log "runner 脚本: $runnerFile"

    # 4. 隐藏窗口异步运行，主脚本立即返回，不阻塞 Pinwheel
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-WindowStyle', 'Hidden', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $runnerFile + '"'))

    Write-Log '已启动后台任务'
    Write-Output '已提交给 DeepSeek Harness，正在后台处理'
}
catch {
    Write-Log "发生异常: $($_.Exception.Message)"
    Write-Error "执行失败：$($_.Exception.Message)"
    exit 1
}
