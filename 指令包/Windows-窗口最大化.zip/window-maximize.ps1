﻿$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class WinApi {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr hWnd);
}
'@
$h = [WinApi]::GetForegroundWindow()
if ($h -eq [IntPtr]::Zero) { exit 1 }
if ([WinApi]::IsZoomed($h)) { [WinApi]::ShowWindow($h, 9) | Out-Null } else { [WinApi]::ShowWindow($h, 3) | Out-Null }
