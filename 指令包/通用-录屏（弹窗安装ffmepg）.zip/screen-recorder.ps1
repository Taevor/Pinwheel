﻿$ErrorActionPreference = 'Stop'

$tmpDir = Join-Path $env:TEMP 'PinwheelRecorder'
$stateDir = $tmpDir
$statePath = Join-Path $stateDir 'state.json'
$ffmpegCachePath = Join-Path $stateDir 'ffmpeg-path.txt'
$stopFlagPath = Join-Path $stateDir 'stop.flag'
$jobFilePath = Join-Path $stateDir 'worker.json'
$logFile = Join-Path $PSScriptRoot 'run.log'

if (-not (Test-Path -LiteralPath $stateDir)) { New-Item -ItemType Directory -Path $stateDir -Force | Out-Null }

function Write-Diag([string]$m) {
    try { Add-Content -LiteralPath $logFile -Value ((Get-Date -Format 'HH:mm:ss.fff') + ' ' + $m) -Encoding UTF8 } catch { }
}

function Notify-Pinwheel([string]$title, [string]$text, [string]$kind = 'success') {
    try {
        if ($env:PINWHEEL_APP -and (Test-Path -LiteralPath $env:PINWHEEL_APP)) {
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = $env:PINWHEEL_APP
            $psi.Arguments = 'notify "' + $title + '" "' + $text + '" ' + $kind
            $psi.UseShellExecute = $false
            $psi.CreateNoWindow = $true
            [System.Diagnostics.Process]::Start($psi) | Out-Null
        } else {
            Write-Output "[$kind] $title - $text"
        }
    } catch {
        Write-Diag ('通知失败(已忽略): ' + $_.Exception.Message)
    }
}

function Read-State {
    if (-not (Test-Path -LiteralPath $statePath)) { return $null }
    try { return ([System.IO.File]::ReadAllText($statePath) | ConvertFrom-Json) }
    catch { Write-Diag ('读取状态失败: ' + $_.Exception.Message); return $null }
}

function Write-State([int]$WorkerPid, [int]$FfmpegPid, [string]$TempPath, [string]$StartedAt) {
    $dir = Split-Path -Parent $statePath
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $obj = [ordered]@{ WorkerPid = $WorkerPid; FfmpegPid = $FfmpegPid; TempPath = $TempPath; StartedAt = $StartedAt }
    [System.IO.File]::WriteAllText($statePath, ($obj | ConvertTo-Json -Compress), [System.Text.Encoding]::UTF8)
}

function Clear-State {
    Remove-Item -LiteralPath $statePath -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $stopFlagPath -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $jobFilePath -Force -ErrorAction SilentlyContinue
}

function Get-ProcessById([int]$ProcessId) {
    try { return Get-Process -Id $ProcessId -ErrorAction Stop } catch { return $null }
}

function Find-Ffmpeg {
    if (Test-Path -LiteralPath $ffmpegCachePath) {
        $cached = (Get-Content -LiteralPath $ffmpegCachePath -Raw).Trim()
        if ($cached -and (Test-Path -LiteralPath $cached)) { return $cached }
    }
    $cmd = Get-Command ffmpeg.exe -ErrorAction SilentlyContinue
    if ($null -ne $cmd) { Set-Content -LiteralPath $ffmpegCachePath -Value $cmd.Source -Encoding UTF8; return $cmd.Source }
    $candidates = @(
        (Join-Path $env:ProgramFiles 'ffmpeg\bin\ffmpeg.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'ffmpeg\bin\ffmpeg.exe'),
        (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\ffmpeg.exe'),
        (Join-Path $env:USERPROFILE 'scoop\shims\ffmpeg.exe')
    )
    foreach ($c in $candidates) { if (Test-Path -LiteralPath $c) { Set-Content -LiteralPath $ffmpegCachePath -Value $c -Encoding UTF8; return $c } }
    $roots = @(
        (Join-Path $env:LOCALAPPDATA 'Programs'),
        (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages'),
        $env:ProgramFiles,
        ${env:ProgramFiles(x86)},
        (Join-Path $env:USERPROFILE 'Downloads')
    )
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        $found = Get-ChildItem -LiteralPath $root -Filter 'ffmpeg.exe' -File -Recurse -Depth 5 -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($null -ne $found) { Set-Content -LiteralPath $ffmpegCachePath -Value $found.FullName -Encoding UTF8; return $found.FullName }
    }
    return $null
}

function Get-DesktopPath {
    $desktop = [Environment]::GetFolderPath('Desktop')
    if ([string]::IsNullOrWhiteSpace($desktop) -or -not (Test-Path -LiteralPath $desktop)) { $desktop = $env:USERPROFILE }
    return $desktop
}

function Show-InteractiveInstaller {
    # 生成一个纯 PowerShell 的安装弹窗，避免 CMD/BAT 带来的 GBK 乱码
    $installerScript = @'
$Host.UI.RawUI.WindowTitle = "录屏依赖安装 (ffmpeg)"
Clear-Host
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "             录屏功能依赖安装 (ffmpeg)" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "`n正在尝试通过 Windows 自带的 winget 自动安装 ffmpeg。"
Write-Host "这可能需要几十秒到几分钟，请勿关闭本窗口...`n"

$winget = Get-Command winget.exe -ErrorAction SilentlyContinue
if (-not $winget) {
    Write-Host "[提示] 系统找不到 winget，请手动下载安装。" -ForegroundColor Yellow
    goto manual
}

& $winget.Source install --id Gyan.FFmpeg --exact --silent --accept-package-agreements --accept-source-agreements --disable-interactivity

if ($LASTEXITCODE -ne 0) {
    Write-Host "`n[错误] winget 自动安装失败，请手动下载安装。" -ForegroundColor Red
    goto manual
}

Write-Host "`n[成功] ffmpeg 安装完成！" -ForegroundColor Green
Write-Host "请关闭本窗口，重新打开 Pinwheel（或再次触发“录屏”指令）即可正常使用。"
Write-Host "`n按任意键关闭窗口..."
Read-Host | Out-Null
exit 0

:manual
Write-Host "`n请按以下步骤手动安装：" -ForegroundColor Yellow
Write-Host "  1. 用浏览器访问：https://www.gyan.dev/ffmpeg/builds/"
Write-Host "  2. 下载 ffmpeg-release-essentials.zip 并解压"
Write-Host "  3. 将解压出的 bin 文件夹（例如 C:\ffmpeg\bin）加入系统环境变量 Path 中"
Write-Host "  4. 重新打开 Pinwheel 后再次触发录屏。"
Write-Host "`n按任意键关闭窗口..."
Read-Host | Out-Null
exit 1
'@
    $tempPs1 = Join-Path $env:TEMP 'PinwheelInstallFfmpeg.ps1'
    [System.IO.File]::WriteAllText($tempPs1, $installerScript, (New-Object System.Text.UTF8Encoding($true))) # 带 BOM 的 UTF-8，绝对不乱码
    
    # 启动一个独立的 PowerShell 进程运行它
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'powershell.exe'
    $psi.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $tempPs1 + '"'
    $psi.UseShellExecute = $true
    $psi.WindowStyle = 'Normal'
    [System.Diagnostics.Process]::Start($psi) | Out-Null
}

function New-DestinationPath([string]$desktop) {
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $dest = Join-Path $desktop ('录屏_' + $stamp + '.mp4')
    $suffix = 1
    while (Test-Path -LiteralPath $dest) { $suffix++; $dest = Join-Path $desktop ('录屏_' + $stamp + '_' + $suffix + '.mp4') }
    return $dest
}

function Start-Worker([string]$ffmpeg, [string]$tempPath) {
    $job = [ordered]@{ Ffmpeg = $ffmpeg; TempDir = $tmpDir; TempPath = $tempPath; StatePath = $statePath; StopFlag = $stopFlagPath; StartedAt = (Get-Date).ToString('o') }
    [System.IO.File]::WriteAllText($jobFilePath, ($job | ConvertTo-Json -Compress), [System.Text.Encoding]::UTF8)
    $argString = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -Worker -JobFile "' + $jobFilePath + '"'
    $workerOutLog = Join-Path $tmpDir 'worker_out.log'
    $workerErrLog = Join-Path $tmpDir 'worker_err.log'
    Start-Process -FilePath 'powershell.exe' -ArgumentList $argString -WindowStyle Hidden -RedirectStandardOutput $workerOutLog -RedirectStandardError $workerErrLog | Out-Null
    Write-Diag ('已启动 worker: ' + $argString)
}

function WorkerMain([string]$jobFile) {
    $proc = $null
    try {
        if (-not (Test-Path -LiteralPath $jobFile)) { Write-Diag 'worker 找不到任务文件'; exit 1 }
        $job = Get-Content -LiteralPath $jobFile -Raw -Encoding UTF8 | ConvertFrom-Json
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $job.Ffmpeg
        $psi.WorkingDirectory = $job.TempDir
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardInput = $true
        $psi.Arguments = '-hide_banner -loglevel error -f gdigrab -framerate 30 -draw_mouse 1 -i desktop -c:v libx264 -preset veryfast -crf 23 -pix_fmt yuv420p -y ' + [System.IO.Path]::GetFileName($job.TempPath)
        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi
        $proc.Start() | Out-Null
        Write-State -WorkerPid $PID -FfmpegPid $proc.Id -TempPath $job.TempPath -StartedAt $job.StartedAt
        Write-Diag ('worker 开始录屏: ffmpeg pid=' + $proc.Id)
        Notify-Pinwheel '录屏' '已开始录屏，再次触发即可停止' 'info'
        while (-not $proc.HasExited) {
            if (Test-Path -LiteralPath $job.StopFlag) { break }
            Start-Sleep -Milliseconds 300
        }
        $stoppedByUser = Test-Path -LiteralPath $job.StopFlag
        if (-not $proc.HasExited) {
            try { $proc.StandardInput.WriteLine('q'); $proc.StandardInput.Flush() } catch { Write-Diag ('发送停止命令失败: ' + $_.Exception.Message) }
            if (-not $proc.WaitForExit(15000)) { Write-Diag 'ffmpeg 未在 15 秒内退出，强制结束'; try { $proc.Kill() } catch { } }
        }
        $proc.WaitForExit()
        Finalize-Recording $job $stoppedByUser
    }
    catch {
        Write-Diag ('worker 异常: ' + $_.Exception.Message)
        if ($null -ne $proc) { try { if (-not $proc.HasExited) { $proc.Kill() } } catch { } }
        Clear-State
        Notify-Pinwheel '录屏' '录屏出现问题，请查看指令目录里的 run.log' 'error'
        exit 1
    }
}

function Finalize-Recording($job, [bool]$stoppedByUser) {
    if (-not (Test-Path -LiteralPath $job.TempPath)) {
        Write-Diag ('停止失败，未找到录制文件: ' + $job.TempPath)
        Clear-State
        Notify-Pinwheel '录屏' '停止失败，没有找到录制文件' 'error'
        exit 1
    }
    $desktop = Get-DesktopPath
    $dest = New-DestinationPath $desktop
    try { Move-Item -LiteralPath $job.TempPath -Destination $dest -Force }
    catch {
        Write-Diag ('移动文件失败: ' + $_.Exception.Message)
        Clear-State
        Notify-Pinwheel '录屏' '保存到桌面失败，录制文件仍在临时目录' 'error'
        exit 1
    }
    $durationText = ''
    if ($job.StartedAt) {
        try {
            $started = [datetime]$job.StartedAt
            $span = (Get-Date) - $started
            if ($span.TotalSeconds -ge 0) { $durationText = '，时长 ' + [int]$span.TotalMinutes + ' 分 ' + [int]($span.TotalSeconds % 60) + ' 秒' }
        } catch { }
    }
    Write-Diag ('停止录屏，已保存到: ' + $dest)
    Clear-State
    Notify-Pinwheel '录屏' ('已保存到桌面：' + (Split-Path -Leaf $dest) + $durationText) 'success'
    exit 0
}

function Main {
    $state = Read-State
    if ($null -ne $state) {
        $worker = Get-ProcessById ([int]$state.WorkerPid)
        if ($null -ne $worker) {
            [System.IO.File]::WriteAllText($stopFlagPath, 'stop', [System.Text.Encoding]::UTF8)
            Write-Diag '已发出停止信号'
            exit 0
        }
        Write-Diag '上次录制的 worker 已不在，清理状态'
        Clear-State
        Write-Error '上次录制已中断。'
        exit 1
    }

    $ffmpeg = Find-Ffmpeg
    if ($null -eq $ffmpeg) {
        # 没找到 ffmpeg，弹窗提示并打开安装窗口
        Write-Diag '未找到 ffmpeg，弹出安装窗口'
        Notify-Pinwheel '录屏' '首次使用需要 ffmpeg，已为您弹出安装窗口，请按窗口提示操作。' 'warning'
        
        Show-InteractiveInstaller
        
        Write-Output '已弹出 ffmpeg 安装窗口，请在窗口中完成安装后，再次触发录屏。'
        exit 0
    }

    if (-not (Test-Path -LiteralPath $tmpDir)) { New-Item -ItemType Directory -Path $tmpDir -Force | Out-Null }
    Get-ChildItem -Path (Join-Path $tmpDir 'rec_*.mp4') -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    Clear-State

    $tempPath = Join-Path $tmpDir ('rec_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.mp4')
    Start-Worker $ffmpeg $tempPath

    $deadline = (Get-Date).AddSeconds(3)
    while (-not (Test-Path -LiteralPath $statePath) -and (Get-Date) -lt $deadline) { Start-Sleep -Milliseconds 200 }
    if (-not (Test-Path -LiteralPath $statePath)) {
        Write-Diag 'worker 未能在 3 秒内启动'
        Write-Error '开始录屏失败，请查看指令目录里的 run.log'
        exit 1
    }
}

$isWorker = $false
$jobFileArg = $null
for ($i = 0; $i -lt $args.Count; $i++) {
    if ($args[$i] -eq '-Worker') { $isWorker = $true }
    elseif ($args[$i] -eq '-JobFile' -and ($i + 1) -lt $args.Count) { $jobFileArg = $args[$i + 1] }
}

if ($isWorker) { WorkerMain $jobFileArg }
else { Main }